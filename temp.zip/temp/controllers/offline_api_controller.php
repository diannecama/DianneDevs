<?php
/**
 * Offline API Controller for Evacuation System
 * Centralized API endpoints using Db.php connection
 */

require_once '../app/Db.php';

class OfflineApiController {
    private $db;
    
    public function __construct() {
        $this->db = Db::getConnection();
    }
    
    /**
     * Get all shelters
     */
    public function getShelters() {
        try {
        $stmt = $this->db->prepare("
            SELECT 
                shelter_id, barangay, owner_name, capacity,
                typhoon_zone, flood_zone, landslide_zone, liquefaction_zone,
                elevation, latitude, longitude,
                building_material_type, building_condition,
                water_supply, electricity, road_condition,
                estimated_travel_time, near_main_road, is_safe_shelter, is_active,
                created_at, updated_at
            FROM shelters 
                WHERE is_active = 1
                ORDER BY barangay, owner_name
        ");
        $stmt->execute();
            $shelters = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $shelters,
                'count' => count($shelters)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get shelters by barangay
     */
    public function getSheltersByBarangay($barangay) {
        try {
        $stmt = $this->db->prepare("
                SELECT * FROM shelters 
                WHERE barangay = ? AND is_active = 1
                ORDER BY capacity DESC
            ");
            $stmt->execute([$barangay]);
            $shelters = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $shelters,
                'count' => count($shelters)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get nearest shelters
     */
    public function getNearestShelters($lat, $lng, $limit = 5) {
        try {
        $stmt = $this->db->prepare("
            SELECT 
                    shelter_id, barangay, owner_name, capacity,
                    typhoon_zone, flood_zone, landslide_zone, liquefaction_zone,
                    elevation, latitude, longitude,
                    building_material_type, building_condition,
                    water_supply, electricity, road_condition,
                    estimated_travel_time, near_main_road, is_safe_shelter, is_active,
                    created_at, updated_at,
                    (
                        6371 * acos(
                            cos(radians(?)) * cos(radians(latitude)) * 
                            cos(radians(longitude) - radians(?)) + 
                            sin(radians(?)) * sin(radians(latitude))
                        )
                    ) AS distance
                FROM shelters 
                WHERE is_active = 1
                HAVING distance < 10
                ORDER BY distance
                LIMIT ?
            ");
            $stmt->execute([$lat, $lng, $lat, $limit]);
            $shelters = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $shelters,
                'count' => count($shelters)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get safe shelters (filtered by safety criteria)
     */
    public function getSafeShelters($typhoon = true, $flood = true, $landslide = true) {
        try {
            $conditions = [];
            $params = [];
            
            if ($typhoon) {
                $conditions[] = "typhoon_safe = 1";
            }
            if ($flood) {
                $conditions[] = "flood_safe = 1";
            }
            if ($landslide) {
                $conditions[] = "landslide_safe = 1";
            }
            
            $whereClause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";
            
            $stmt = $this->db->prepare("
                SELECT * FROM shelters 
                $whereClause AND is_active = 1
                ORDER BY capacity DESC
            ");
            $stmt->execute($params);
            $shelters = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $shelters,
                'count' => count($shelters)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Update shelter occupancy
     */
    public function updateShelterOccupancy($shelterId, $occupants) {
        try {
            // Check if shelter exists and has capacity
            $stmt = $this->db->prepare("
                SELECT capacity, current_occupants FROM shelters 
                WHERE id = ? AND is_active = 1
            ");
            $stmt->execute([$shelterId]);
            $shelter = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$shelter) {
                return [
                    'success' => false,
                    'error' => 'Shelter not found'
                ];
            }
            
            if ($occupants > $shelter['capacity']) {
                return [
                    'success' => false,
                    'error' => 'Occupancy exceeds capacity'
                ];
            }
            
            // Update occupancy
            $stmt = $this->db->prepare("
                UPDATE shelters 
                SET current_occupants = ?, last_updated = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$occupants, $shelterId]);
            
            return [
                'success' => true,
                'message' => 'Shelter occupancy updated successfully'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get system statistics
     */
    public function getSystemStats() {
        try {
            // Total shelters
            $stmt = $this->db->query("SELECT COUNT(*) as total FROM shelters WHERE is_active = 1");
            $totalShelters = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
            
            // Available shelters (with space)
            $stmt = $this->db->query("
                SELECT COUNT(*) as available 
                FROM shelters 
                WHERE current_occupants < capacity AND is_active = 1
            ");
            $availableShelters = $stmt->fetch(PDO::FETCH_ASSOC)['available'];
            
            // Total capacity
            $stmt = $this->db->query("SELECT SUM(capacity) as total_capacity FROM shelters WHERE is_active = 1");
            $totalCapacity = $stmt->fetch(PDO::FETCH_ASSOC)['total_capacity'];
            
            // Current occupants
            $stmt = $this->db->query("SELECT SUM(current_occupants) as total_occupants FROM shelters WHERE is_active = 1");
            $totalOccupants = $stmt->fetch(PDO::FETCH_ASSOC)['total_occupants'];
            
            // Safe shelters
            $stmt = $this->db->query("
                SELECT COUNT(*) as safe_shelters 
                FROM shelters 
                WHERE typhoon_safe = 1 AND flood_safe = 1 AND landslide_safe = 1 AND is_active = 1
            ");
            $safeShelters = $stmt->fetch(PDO::FETCH_ASSOC)['safe_shelters'];
            
            return [
                'success' => true,
                'data' => [
                    'total_shelters' => (int)$totalShelters,
                    'available_shelters' => (int)$availableShelters,
                    'total_capacity' => (int)$totalCapacity,
                    'total_occupants' => (int)$totalOccupants,
                    'available_capacity' => (int)($totalCapacity - $totalOccupants),
                    'safe_shelters' => (int)$safeShelters,
                    'last_updated' => date('Y-m-d H:i:s')
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get emergency alerts
     */
    public function getEmergencyAlerts() {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM emergency_alerts 
                WHERE is_active = 1 AND alert_end IS NULL OR alert_end > NOW()
                ORDER BY severity DESC, alert_start DESC
            ");
            $stmt->execute();
            $alerts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $alerts,
                'count' => count($alerts)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get safe routes
     */
    public function getSafeRoutes() {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM routes 
                WHERE is_safe = 1 AND is_active = 1
                ORDER BY risk_level, distance
            ");
            $stmt->execute();
            $routes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $routes,
                'count' => count($routes)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Log user session
     */
    public function logUserSession($sessionData) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO user_sessions (
                    session_id, timestamp, user_location, selected_shelter, 
                    route_data, preferences, created_at
                ) VALUES (?, NOW(), ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $sessionData['session_id'] ?? uniqid(),
                $sessionData['user_location'] ?? null,
                $sessionData['selected_shelter'] ?? null,
                $sessionData['route_data'] ?? null,
                $sessionData['preferences'] ?? null
            ]);
            
            return [
                'success' => true,
                'message' => 'Session logged successfully'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get current location data
     */
    public function getCurrentLocation() {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    id, latitude, longitude, created_at, updated_at
                FROM mycurrentlocation 
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $stmt->execute();
            $location = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return [
                'success' => true,
                'data' => $location,
                'count' => $location ? 1 : 0
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Save current location
     */
    public function saveCurrentLocation($latitude, $longitude) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO mycurrentlocation (latitude, longitude) 
                VALUES (?, ?)
            ");
            $stmt->execute([$latitude, $longitude]);
            
            return [
                'success' => true,
                'message' => 'Location saved successfully',
                'id' => $this->db->lastInsertId()
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $controller = new OfflineApiController();
    $action = $_GET['action'] ?? 'shelters';
    
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
    header('Access-Control-Allow-Headers: Content-Type');
    
    switch ($action) {
        case 'shelters':
            $response = $controller->getShelters();
            break;
            
        case 'shelters_by_barangay':
            $barangay = $_GET['barangay'] ?? '';
            $response = $controller->getSheltersByBarangay($barangay);
            break;
            
        case 'nearest_shelters':
            $lat = $_GET['lat'] ?? 14.5995;
            $lng = $_GET['lng'] ?? 120.9842;
            $limit = $_GET['limit'] ?? 5;
            $response = $controller->getNearestShelters($lat, $lng, $limit);
            break;
            
        case 'safe_shelters':
            $typhoon = isset($_GET['typhoon']) ? (bool)$_GET['typhoon'] : true;
            $flood = isset($_GET['flood']) ? (bool)$_GET['flood'] : true;
            $landslide = isset($_GET['landslide']) ? (bool)$_GET['landslide'] : true;
            $response = $controller->getSafeShelters($typhoon, $flood, $landslide);
            break;
            
        case 'stats':
            $response = $controller->getSystemStats();
            break;
            
        case 'alerts':
            $response = $controller->getEmergencyAlerts();
            break;
            
        case 'routes':
            $response = $controller->getSafeRoutes();
            break;
            
        case 'current_location':
            $response = $controller->getCurrentLocation();
            break;
            
        default:
            $response = [
                'success' => false,
                'error' => 'Invalid action'
            ];
    }
    
    echo json_encode($response);
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new OfflineApiController();
    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
    header('Access-Control-Allow-Headers: Content-Type');
    
    switch ($action) {
        case 'update_occupancy':
            $shelterId = $_POST['shelter_id'] ?? 0;
            $occupants = $_POST['occupants'] ?? 0;
            $response = $controller->updateShelterOccupancy($shelterId, $occupants);
            break;
            
        case 'log_session':
            $sessionData = [
                'session_id' => $_POST['session_id'] ?? null,
                'user_location' => $_POST['user_location'] ?? null,
                'selected_shelter' => $_POST['selected_shelter'] ?? null,
                'route_data' => $_POST['route_data'] ?? null,
                'preferences' => $_POST['preferences'] ?? null
            ];
            $response = $controller->logUserSession($sessionData);
            break;
            
        case 'save_location':
            $latitude = $_POST['latitude'] ?? null;
            $longitude = $_POST['longitude'] ?? null;
            $response = $controller->saveCurrentLocation($latitude, $longitude);
            break;
            
        default:
            $response = [
            'success' => false,
                'error' => 'Invalid action'
            ];
    }
    
    echo json_encode($response);
}
?>
