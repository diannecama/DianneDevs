DROP DATABASE IF EXISTS evacuation_system;
CREATE DATABASE evacuation_system;
USE evacuation_system;

CREATE TABLE users (
    user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    is_admin TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE shelters (
    shelter_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    barangay VARCHAR(50) NOT NULL,
    owner_name VARCHAR(100) NOT NULL,
    capacity VARCHAR(100) NOT NULL,
    typhoon_zone ENUM('Yes', 'No') NOT NULL,
    flood_zone ENUM('Yes', 'No') NOT NULL,
    landslide_zone ENUM('Yes', 'No') NOT NULL,
    liquefaction_zone ENUM('Yes', 'No') NOT NULL,
    storm_surge_zone ENUM('Yes', 'No') NOT NULL,
    elevation DECIMAL(10, 2) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    building_material_type VARCHAR(50) NOT NULL,
    building_condition VARCHAR(50) NOT NULL,
    water_supply VARCHAR(50) NOT NULL,
    electricity VARCHAR(50) NOT NULL,
    road_condition VARCHAR(50) NOT NULL,
    estimated_travel_time VARCHAR(50) NOT NULL,
    near_main_road ENUM('Yes', 'No') NOT NULL,
    is_safe_shelter TINYINT(1) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE mycurrentlocation (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
);

-- Sample INSERT statement for mycurrentlocation table
INSERT INTO mycurrentlocation (latitude, longitude) VALUES (13.55683558, 124.19982281);

INSERT INTO users (username, password, is_admin) VALUES ('admin', 'admin', 1);
INSERT INTO users (username, password, is_admin) VALUES ('user', 'user', 0);