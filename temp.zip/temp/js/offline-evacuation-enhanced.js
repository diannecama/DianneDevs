// Enhanced Offline Evacuation System with Leaflet.js and localStorage
class EnhancedOfflineEvacuationSystem {
    constructor() {
        this.map = null;
        this.userLocation = null;
        this.isOnline = navigator.onLine;
        this.lastSyncTime = null;
        this.localData = {
            shelters: [],
            routes: [],
            dangerZones: [],
            barangays: [],
            mapTiles: new Set(),
            userPreferences: {},
            cachedRoutes: []
        };
        this.layers = {};
        this.routingControl = null;
        this.currentRoute = null;
        this.geolocationWatchId = null;
        this.offlineMode = false;
        this.init();
    }

    async init() {
    console.log("🚀 Initializing Enhanced Offline Evacuation System...");

    try {
        await this.initializeMap();
        this.setupOfflineDetection();
        await this.loadLocalData();
        this.startLocationTracking();
        this.setupLayerControls();
        this.startPeriodicSync();
        this.updateUI();
        this.preloadMapTiles();

        // Hide loading overlay
        const loadingOverlay = document.getElementById('loadingOverlay');
        if (loadingOverlay) loadingOverlay.style.display = 'none';

    } catch (error) {
        console.error("❌ Initialization failed (handled silently):", error);
        // DO NOT call this.showError() or any modal
    }
}

    async initializeMap() {
        console.log("🗺️ Initializing map...");
        
        // Initialize map with dark theme
        this.map = L.map('map', {
            zoomControl: true,
            scrollWheelZoom: true,
            attributionControl: true,
            preferCanvas: true
        }).setView([14.5995, 120.9842], 13); // Manila center

        // Add multiple tile layers for offline capability
        const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        });

        const cartoDarkLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '© OpenStreetMap contributors © CARTO',
            maxZoom: 19
        });

        const cartoLightLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            attribution: '© OpenStreetMap contributors © CARTO',
            maxZoom: 19
        });

        // Store tile layers for switching
        this.tileLayers = {
            dark: cartoDarkLayer,
            light: cartoLightLayer,
            street: osmLayer
        };

        // Use dark theme by default
        this.currentTileLayer = cartoDarkLayer;
        this.currentTileLayer.addTo(this.map);

        // Add layer control
        const baseMaps = {
            "Dark Map": cartoDarkLayer,
            "Light Map": cartoLightLayer,
            "Street Map": osmLayer
        };

        L.control.layers(baseMaps).addTo(this.map);

        // Add scale control
        L.control.scale({
            position: 'bottomright',
            metric: true,
            imperial: false
        }).addTo(this.map);

        // Add custom controls
        this.addCustomControls();
    }

    addCustomControls() {
        // Add offline mode toggle
        const offlineControl = L.control({ position: 'topright' });
        offlineControl.onAdd = () => {
            const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control leaflet-control-custom');
            div.innerHTML = '<button id="offlineToggle" title="Toggle Offline Mode"><i class="fas fa-wifi"></i></button>';
            div.style.backgroundColor = 'rgba(26, 26, 26, 0.8)';
            div.style.border = '1px solid #404040';
            div.style.borderRadius = '5px';
            
            L.DomEvent.on(div, 'click', () => {
                this.toggleOfflineMode();
            });
            
            return div;
        };
        offlineControl.addTo(this.map);

        // Add sync control
        const syncControl = L.control({ position: 'topright' });
        syncControl.onAdd = () => {
            const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control leaflet-control-custom');
            div.innerHTML = '<button id="syncButton" title="Sync Data"><i class="fas fa-sync-alt"></i></button>';
            div.style.backgroundColor = 'rgba(26, 26, 26, 0.8)';
            div.style.border = '1px solid #404040';
            div.style.borderRadius = '5px';
            div.style.marginTop = '5px';
            
            L.DomEvent.on(div, 'click', () => {
                this.syncData();
            });
            
            return div;
        };
        syncControl.addTo(this.map);
    }

    setupOfflineDetection() {
    console.log("📡 Reliable Offline Detection Enabled");

    // 1️⃣ Get last saved state
    const saved = localStorage.getItem("connectionStatus");
    const forced = localStorage.getItem("forceOffline") === "true";

    if (forced || saved === "offline") {
        this.isOnline = false;
    } else if (saved === "online") {
        this.isOnline = true;
    } else {
        this.isOnline = navigator.onLine;
    }

    // 2️⃣ Save current state
    localStorage.setItem("connectionStatus", this.isOnline ? "online" : "offline");

    // 3️⃣ When connection goes offline
    window.addEventListener("offline", () => {
        console.log("⚠️ Offline mode activated");
        this.isOnline = false;
        localStorage.setItem("connectionStatus", "offline");
        localStorage.setItem("forceOffline", "true");
        this.updateConnectionStatus();
        this.showOfflineIndicator?.();
    });

    // 4️⃣ When connection comes back
    window.addEventListener("online", () => {
        console.log("✅ Connection restored");
        this.isOnline = true;
        localStorage.setItem("connectionStatus", "online");
        localStorage.setItem("forceOffline", "false");
        this.updateConnectionStatus();
        this.syncData?.();
    });

    // 5️⃣ Force override of navigator.onLine
    const self = this;
    try {
        Object.defineProperty(window.navigator, "onLine", {
            configurable: true,
            get() {
                const forced = localStorage.getItem("forceOffline");
                if (forced === "true") return false;
                return self.isOnline;
            }
        });
    } catch (e) {
        console.warn("Navigator override not supported:", e);
    }

    // 6️⃣ Update UI immediately
    this.updateConnectionStatus();

    // ✅ Service worker registration (fixed path for /temp/)
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker
                .register('./sw.js') // ⚠️ relative path sa index.php
                .then(reg => console.log('🛠️ Service Worker registered with scope:', reg.scope))
                .catch(err => console.error('❌ Service Worker registration failed:', err));
        });
    }
}




    async loadSampleData() {
        console.log("📊 Loading sample data...");
        
        const sampleShelters = [
            {
                shelter_id: 1,
                barangay: "Barangay Central",
                owner_name: "Barangay Government",
                capacity: "100",
                typhoon_zone: "No",
                flood_zone: "No",
                landslide_zone: "No",
                storm_surge_zone: "No",
                elevation: 15.5,
                latitude: 14.6080,
                longitude: 120.9900,
                building_material_type: "Concrete",
                building_condition: "Good",
                water_supply: "Available",
                electricity: "Available",
                road_condition: "Good",
                estimated_travel_time: "15 minutes",
                near_main_road: "Yes",
                is_safe_shelter: 1,
                is_active: 1,
                current_occupants: 75,
                contact: "09123456789",
                facilities: ["Water", "Electricity", "Medical"]
            },
            {
                shelter_id: 2,
                barangay: "Barangay Centro",
                owner_name: "Municipal Government",
                capacity: "200",
                typhoon_zone: "No",
                flood_zone: "Yes",
                landslide_zone: "No",
                storm_surge_zone: "No",
                elevation: 8.2,
                latitude: 14.6020,
                longitude: 120.9845,
                building_material_type: "Concrete",
                building_condition: "Good",
                water_supply: "Available",
                electricity: "Available",
                road_condition: "Good",
                estimated_travel_time: "20 minutes",
                near_main_road: "Yes",
                is_safe_shelter: 1,
                is_active: 1,
                current_occupants: 120,
                contact: "09123456790",
                facilities: ["Water", "Electricity", "Medical", "Food"]
            },
            {
                shelter_id: 3,
                barangay: "Barangay North",
                owner_name: "Department of Education",
                capacity: "150",
                typhoon_zone: "No",
                flood_zone: "No",
                landslide_zone: "Yes",
                storm_surge_zone: "No",
                elevation: 25.8,
                latitude: 14.5950,
                longitude: 120.9780,
                building_material_type: "Concrete",
                building_condition: "Fair",
                water_supply: "Available",
                electricity: "Available",
                road_condition: "Fair",
                estimated_travel_time: "25 minutes",
                near_main_road: "No",
                is_safe_shelter: 0,
                is_active: 1,
                current_occupants: 45,
                contact: "09123456791",
                facilities: ["Water", "Electricity"]
            },
            {
                shelter_id: 4,
                barangay: "Barangay South",
                owner_name: "Private Owner",
                capacity: "80",
                typhoon_zone: "No",
                flood_zone: "No",
                landslide_zone: "No",
                storm_surge_zone: "Yes",
                elevation: 5.2,
                latitude: 14.5900,
                longitude: 120.9750,
                building_material_type: "Mixed",
                building_condition: "Good",
                water_supply: "Limited",
                electricity: "Available",
                road_condition: "Good",
                estimated_travel_time: "10 minutes",
                near_main_road: "Yes",
                is_safe_shelter: 1,
                is_active: 1,
                current_occupants: 30,
                contact: "09123456792",
                facilities: ["Water", "Electricity"]
            }
        ];

        const sampleRoutes = [
            {
                id: 1,
                route_name: "Safe Route to Evacuation Center",
                is_safe: true,
                risk_level: "low",
                distance: 1.2,
                estimated_time: 15,
                path_coordinates: JSON.stringify([
                    [14.5995, 120.9842],
                    [14.6020, 120.9860],
                    [14.6035, 120.9870],
                    [14.6050, 120.9880]
                ])
            }
        ];

        const sampleDangerZones = [
            {
                id: 1,
                name: "Flood Prone Area",
                type: "Flood",
                risk_level: "High",
                description: "Area prone to flooding during heavy rains",
                coordinates: JSON.stringify([
                    [14.5900, 120.9800],
                    [14.5920, 120.9800],
                    [14.5920, 120.9820],
                    [14.5900, 120.9820]
                ])
            }
        ];

        // Update local data
        this.localData.shelters = sampleShelters;
        this.localData.routes = sampleRoutes;
        this.localData.dangerZones = sampleDangerZones;
        
        // Store in localStorage
        localStorage.setItem('evacuationData', JSON.stringify(this.localData));
        
        // Store in IndexedDB
        if ('indexedDB' in window) {
            await this.storeDataInIndexedDB();
        }
    }

    async loadFromIndexedDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('EvacuationDB', 1);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                const db = request.result;
                const transaction = db.transaction(['shelters', 'routes', 'dangerZones', 'barangays'], 'readonly');
                
                // Load shelters
                const shelterStore = transaction.objectStore('shelters');
                const shelterRequest = shelterStore.getAll();
                shelterRequest.onsuccess = () => {
                    this.localData.shelters = shelterRequest.result || [];
                };

                // Load routes
                const routeStore = transaction.objectStore('routes');
                const routeRequest = routeStore.getAll();
                routeRequest.onsuccess = () => {
                    this.localData.routes = routeRequest.result || [];
                };

                // Load danger zones
                const dangerStore = transaction.objectStore('dangerZones');
                const dangerRequest = dangerStore.getAll();
                dangerRequest.onsuccess = () => {
                    this.localData.dangerZones = dangerRequest.result || [];
                };

                // Load barangays
                const barangayStore = transaction.objectStore('barangays');
                const barangayRequest = barangayStore.getAll();
                barangayRequest.onsuccess = () => {
                    this.localData.barangays = barangayRequest.result || [];
                };

                transaction.oncomplete = () => resolve();
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Create object stores
                if (!db.objectStoreNames.contains('shelters')) {
                    db.createObjectStore('shelters', { keyPath: 'shelter_id' });
                }
                if (!db.objectStoreNames.contains('routes')) {
                    db.createObjectStore('routes', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('dangerZones')) {
                    db.createObjectStore('dangerZones', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('barangays')) {
                    db.createObjectStore('barangays', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('mapTiles')) {
                    db.createObjectStore('mapTiles', { keyPath: 'url' });
                }
            };
        });
    }

    renderLocalData() {
        console.log("🎨 Rendering local data on map...");
        console.log("📊 Data counts:", {
            shelters: this.localData.shelters ? this.localData.shelters.length : 0,
            routes: this.localData.routes ? this.localData.routes.length : 0,
            dangerZones: this.localData.dangerZones ? this.localData.dangerZones.length : 0,
            barangays: this.localData.barangays ? this.localData.barangays.length : 0
        });
        
        // Clear existing layers
        Object.values(this.layers).forEach(layer => {
            if (layer && this.map.hasLayer(layer)) {
                this.map.removeLayer(layer);
            }
        });

        // Render shelters
        this.renderShelters();
        
        // Render routes
        this.renderRoutes();
        
        // Render danger zones
        this.renderDangerZones();
        
        // Render barangay boundaries
        this.renderBarangayBoundaries();
    }

    renderShelters() {
        if (!this.layers.shelters) {
            this.layers.shelters = L.layerGroup();
        }

        this.layers.shelters.clearLayers();

        this.localData.shelters.forEach(shelter => {
            const marker = L.marker([shelter.latitude, shelter.longitude], {
                icon: this.createShelterIcon(shelter)
            });

            const popupContent = this.createShelterPopup(shelter);
            marker.bindPopup(popupContent);

            // Add click event for routing
            marker.on('click', () => {
                if (this.userLocation) {
                    this.createRouteToShelter(shelter);
                }
            });

            this.layers.shelters.addLayer(marker);
        });

        if (document.getElementById('layerShelters').checked) {
            this.map.addLayer(this.layers.shelters);
        }
    }

    createShelterIcon(shelter) {
        const capacity = parseInt(shelter.capacity) || 0;
        const currentOccupants = shelter.current_occupants || 0;
        const occupancyRate = capacity > 0 ? (currentOccupants / capacity) * 100 : 0;
        const isSafe = shelter.is_safe_shelter === 1;
        const isActive = shelter.is_active === 1;

        let color = '#28a745'; // Green - safe and available
        let icon = 'fas fa-home';
        
        if (!isActive) {
            color = '#6c757d'; // Gray - inactive
            icon = 'fas fa-ban';
        } else if (!isSafe) {
            color = '#dc3545'; // Red - unsafe
            icon = 'fas fa-exclamation-triangle';
        } else if (occupancyRate >= 90) {
            color = '#dc3545'; // Red - full
            icon = 'fas fa-home';
        } else if (occupancyRate >= 70) {
            color = '#ffc107'; // Yellow - warning
            icon = 'fas fa-home';
        }

        return L.divIcon({
            className: 'custom-shelter-icon',
            html: `<div style="
                width: 24px; 
                height: 24px; 
                background-color: ${color}; 
                border: 3px solid white; 
                border-radius: 50%; 
                display: flex; 
                align-items: center; 
                justify-content: center;
                box-shadow: 0 3px 6px rgba(0,0,0,0.4);
                cursor: pointer;
            "><i class="${icon}" style="color: white; font-size: 12px;"></i></div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
        });
    }

    createShelterPopup(shelter) {
        const capacity = parseInt(shelter.capacity) || 0;
        const currentOccupants = shelter.current_occupants || 0;
        const available = capacity - currentOccupants;
        const occupancyRate = capacity > 0 ? Math.round((currentOccupants / capacity) * 100) : 0;
        const isSafe = shelter.is_safe_shelter === 1;
        const isActive = shelter.is_active === 1;

        return `
            <div class="custom-popup">
                <div class="popup-title">${shelter.barangay} Shelter</div>
                <div class="popup-info"><strong>Owner:</strong> ${shelter.owner_name}</div>
                <div class="popup-info"><strong>Barangay:</strong> ${shelter.barangay}</div>
                <div class="popup-info"><strong>Capacity:</strong> ${currentOccupants}/${capacity} (${available} available)</div>
                <div class="popup-info"><strong>Occupancy:</strong> ${occupancyRate}%</div>
                <div class="popup-info"><strong>Status:</strong> 
                    <span style="color: ${isActive ? (isSafe ? '#28a745' : '#dc3545') : '#6c757d'}">
                        ${isActive ? (isSafe ? 'Safe' : 'Unsafe') : 'Inactive'}
                    </span>
                </div>
                <div class="popup-info"><strong>Hazard Zones:</strong> 
                    ${shelter.typhoon_zone === 'Yes' ? '🌪️' : ''} 
                    ${shelter.flood_zone === 'Yes' ? '🌊' : ''} 
                    ${shelter.landslide_zone === 'Yes' ? '🏔️' : ''}
                    ${shelter.liquefaction_zone === 'Yes' ? '🌊' : ''}
                    ${shelter.storm_surge_zone === 'Yes' ? '🌊' : ''}
                </div>
                <div class="popup-info"><strong>Elevation:</strong> ${shelter.elevation}m</div>
                <div class="popup-info"><strong>Building:</strong> ${shelter.building_material_type} (${shelter.building_condition})</div>
                <div class="popup-info"><strong>Utilities:</strong> Water: ${shelter.water_supply}, Power: ${shelter.electricity}</div>
                <div class="popup-info"><strong>Road:</strong> ${shelter.road_condition} ${shelter.near_main_road === 'Yes' ? '(Near main road)' : ''}</div>
                <div class="popup-info"><strong>Travel Time:</strong> ${shelter.estimated_travel_time}</div>
                <div class="popup-info"><strong>Contact:</strong> ${shelter.contact || 'N/A'}</div>
                <div style="margin-top: 10px;">
                    <button onclick="evacuationSystem.createRouteToShelter(${JSON.stringify(shelter).replace(/"/g, '&quot;')})" 
                            style="background: var(--accent-color); color: white; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer;">
                        <i class="fas fa-route"></i> Get Directions
                    </button>
                </div>
            </div>
        `;
    }

    renderRoutes() {
        if (!this.layers.routes) {
            this.layers.routes = L.layerGroup();
        }

        this.layers.routes.clearLayers();

        this.localData.routes.forEach(route => {
            if (route.path_coordinates) {
                try {
                    const coordinates = JSON.parse(route.path_coordinates);
                    const polyline = L.polyline(coordinates, {
                        color: route.is_safe ? '#28a745' : '#dc3545',
                        weight: 4,
                        opacity: 0.8,
                        dashArray: route.is_safe ? null : '10, 5'
                    });

                    const popupContent = this.createRoutePopup(route);
                    polyline.bindPopup(popupContent);

                    this.layers.routes.addLayer(polyline);
                } catch (error) {
                    console.error("Error parsing route coordinates:", error);
                }
            }
        });

        if (document.getElementById('layerRoutes').checked) {
            this.map.addLayer(this.layers.routes);
        }
    }

    createRoutePopup(route) {
        const riskLevel = route.risk_level || 'medium';
        const riskColor = {
            'low': '#28a745',
            'medium': '#ffc107',
            'high': '#dc3545'
        }[riskLevel] || '#ffc107';

        return `
            <div class="custom-popup">
                <div class="popup-title">${route.route_name}</div>
                <div class="popup-info"><strong>Status:</strong> 
                    <span style="color: ${route.is_safe ? '#28a745' : '#dc3545'}">
                        ${route.is_safe ? 'Safe' : 'Dangerous'}
                    </span>
                </div>
                <div class="popup-info"><strong>Risk Level:</strong> 
                    <span style="color: ${riskColor}">${riskLevel.toUpperCase()}</span>
                </div>
                <div class="popup-info"><strong>Distance:</strong> ${route.distance || 0} km</div>
                <div class="popup-info"><strong>Time:</strong> ${route.estimated_time || 0} min</div>
            </div>
        `;
    }

    renderDangerZones() {
        if (!this.layers.dangerZones) {
            this.layers.dangerZones = L.layerGroup();
        }

        this.layers.dangerZones.clearLayers();

        this.localData.dangerZones.forEach(zone => {
            if (zone.coordinates) {
                try {
                    const coordinates = JSON.parse(zone.coordinates);
                    const polygon = L.polygon(coordinates, {
                        color: '#dc3545',
                        fillColor: '#dc3545',
                        fillOpacity: 0.3,
                        weight: 2
                    });

                    const popupContent = this.createDangerZonePopup(zone);
                    polygon.bindPopup(popupContent);

                    this.layers.dangerZones.addLayer(polygon);
                } catch (error) {
                    console.error("Error parsing danger zone coordinates:", error);
                }
            }
        });

        if (document.getElementById('layerDangerZones').checked) {
            this.map.addLayer(this.layers.dangerZones);
        }
    }

    createDangerZonePopup(zone) {
        return `
            <div class="custom-popup">
                <div class="popup-title">${zone.name}</div>
                <div class="popup-info"><strong>Type:</strong> ${zone.type}</div>
                <div class="popup-info"><strong>Risk Level:</strong> ${zone.risk_level}</div>
                <div class="popup-info"><strong>Description:</strong> ${zone.description}</div>
            </div>
        `;
    }

    renderBarangayBoundaries() {
        if (!this.layers.barangays) {
            this.layers.barangays = L.layerGroup();
        }

        this.layers.barangays.clearLayers();

        this.localData.barangays.forEach(barangay => {
            if (barangay.boundaries) {
                try {
                    const coordinates = JSON.parse(barangay.boundaries);
                    const polygon = L.polygon(coordinates, {
                        color: '#0078D4',
                        fillColor: '#0078D4',
                        fillOpacity: 0.1,
                        weight: 1
                    });

                    const popupContent = this.createBarangayPopup(barangay);
                    polygon.bindPopup(popupContent);

                    this.layers.barangays.addLayer(polygon);
                } catch (error) {
                    console.error("Error parsing barangay boundaries:", error);
                }
            }
        });

        if (document.getElementById('layerBarangays').checked) {
            this.map.addLayer(this.layers.barangays);
        }
    }

    createBarangayPopup(barangay) {
        return `
            <div class="custom-popup">
                <div class="popup-title">${barangay.name}</div>
                <div class="popup-info"><strong>Population:</strong> ${barangay.population || 'N/A'}</div>
                <div class="popup-info"><strong>Shelters:</strong> ${barangay.shelter_count || 0}</div>
                <div class="popup-info"><strong>Risk Level:</strong> ${barangay.risk_level || 'Unknown'}</div>
            </div>
        `;
    }

    setupLayerControls() {
        const layerCheckboxes = document.querySelectorAll('.layer-item input[type="checkbox"]');
        
        layerCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                const layerName = e.target.id.replace('layer', '').toLowerCase();
                const layer = this.layers[layerName];
                
                if (layer) {
                    if (e.target.checked) {
                        this.map.addLayer(layer);
                    } else {
                        this.map.removeLayer(layer);
                    }
                }
            });
        });
    }

    startLocationTracking() {
        if ('geolocation' in navigator) {
            const watchOptions = {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 60000
            };
            
            this.geolocationWatchId = navigator.geolocation.watchPosition(
                (position) => {
                    this.userLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude,
                        accuracy: position.coords.accuracy
                    };
                    
                    this.updateLocationUI();
                    this.updateNearestShelter();
                    this.addUserLocationMarker();
                },
                (error) => {
                    console.error("GPS error:", error);
                    document.getElementById('gpsStatus').className = 'status-badge status-offline';
                    document.getElementById('gpsStatus').innerHTML = '<i class="fas fa-map-marker-alt"></i> GPS Error';
                },
                watchOptions
            );
        }
    }

    addUserLocationMarker() {
        if (this.userLocationMarker) {
            this.map.removeLayer(this.userLocationMarker);
        }

        this.userLocationMarker = L.marker([this.userLocation.lat, this.userLocation.lng], {
            icon: L.divIcon({
                className: 'user-location-marker',
                html: `<div style="
                    width: 20px; 
                    height: 20px; 
                    background-color: #0078D4; 
                    border: 3px solid white; 
                    border-radius: 50%; 
                    display: flex; 
                    align-items: center; 
                    justify-content: center;
                    box-shadow: 0 3px 6px rgba(0,0,0,0.4);
                "><i class="fas fa-crosshairs" style="color: white; font-size: 10px;"></i></div>`,
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            })
        }).addTo(this.map);

        // Add popup
        this.userLocationMarker.bindPopup(`
            <div class="custom-popup">
                <div class="popup-title">Your Location</div>
                <div class="popup-info"><strong>Latitude:</strong> ${this.userLocation.lat.toFixed(6)}</div>
                <div class="popup-info"><strong>Longitude:</strong> ${this.userLocation.lng.toFixed(6)}</div>
                <div class="popup-info"><strong>Accuracy:</strong> ${Math.round(this.userLocation.accuracy)}m</div>
            </div>
        `);
    }

    updateLocationUI() {
        if (this.userLocation) {
            document.getElementById('currentLat').textContent = this.userLocation.lat.toFixed(6);
            document.getElementById('currentLng').textContent = this.userLocation.lng.toFixed(6);
            document.getElementById('currentAccuracy').textContent = `${Math.round(this.userLocation.accuracy)}m`;
        }
    }

    updateNearestShelter() {
        if (!this.userLocation || this.localData.shelters.length === 0) return;

        let nearestShelter = null;
        let minDistance = Infinity;

        this.localData.shelters.forEach(shelter => {
            const distance = this.calculateDistance(
                this.userLocation.lat, this.userLocation.lng,
                shelter.latitude, shelter.longitude
            );
            
            if (distance < minDistance) {
                minDistance = distance;
                nearestShelter = shelter;
            }
        });

        if (nearestShelter) {
            document.getElementById('nearestShelter').textContent = `${minDistance.toFixed(1)} km`;
        }
    }

    calculateDistance(lat1, lng1, lat2, lng2) {
        const R = 6371; // Earth's radius in kilometers
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLng/2) * Math.sin(dLng/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    createRouteToShelter(shelter) {
        if (!this.userLocation) {
            alert("Please enable location services to get directions.");
            return;
        }

        // Clear existing route
        if (this.currentRoute) {
            this.map.removeLayer(this.currentRoute);
        }

        // Create route line
        const routeCoordinates = [
            [this.userLocation.lat, this.userLocation.lng],
            [shelter.latitude, shelter.longitude]
        ];

        this.currentRoute = L.polyline(routeCoordinates, {
            color: '#0078D4',
            weight: 5,
            opacity: 0.8,
            dashArray: '10, 5'
        }).addTo(this.map);

        // Add markers for start and end
        const startMarker = L.marker([this.userLocation.lat, this.userLocation.lng], {
            icon: L.divIcon({
                className: 'route-marker',
                html: `<div style="
                    width: 20px; 
                    height: 20px; 
                    background-color: #28a745; 
                    border: 3px solid white; 
                    border-radius: 50%; 
                    display: flex; 
                    align-items: center; 
                    justify-content: center;
                    box-shadow: 0 3px 6px rgba(0,0,0,0.4);
                "><i class="fas fa-play" style="color: white; font-size: 8px;"></i></div>`,
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            })
        }).addTo(this.map);

        const endMarker = L.marker([shelter.latitude, shelter.longitude], {
            icon: L.divIcon({
                className: 'route-marker',
                html: `<div style="
                    width: 20px; 
                    height: 20px; 
                    background-color: #dc3545; 
                    border: 3px solid white; 
                    border-radius: 50%; 
                    display: flex; 
                    align-items: center; 
                    justify-content: center;
                    box-shadow: 0 3px 6px rgba(0,0,0,0.4);
                "><i class="fas fa-flag" style="color: white; font-size: 8px;"></i></div>`,
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            })
        }).addTo(this.map);

        // Calculate distance and time
        const distance = this.calculateDistance(
            this.userLocation.lat, this.userLocation.lng,
            shelter.latitude, shelter.longitude
        );
        const estimatedTime = Math.round(distance * 2); // Rough estimate: 2 minutes per km

        // Show route info
        const routeInfo = `
            <div class="custom-popup">
                <div class="popup-title">Route to ${shelter.name}</div>
                <div class="popup-info"><strong>Distance:</strong> ${distance.toFixed(1)} km</div>
                <div class="popup-info"><strong>Estimated Time:</strong> ${estimatedTime} minutes</div>
                <div class="popup-info"><strong>Destination:</strong> ${shelter.barangay}</div>
            </div>
        `;

        endMarker.bindPopup(routeInfo).openPopup();

        // Fit map to show route
        this.map.fitBounds(this.currentRoute.getBounds(), { padding: [20, 20] });
    }

    async preloadMapTiles() {
        if (!this.isOnline) {
            console.log("📡 Offline mode - skipping tile preloading");
            return;
        }

        console.log("🗺️ Preloading map tiles for offline use...");
        
        const bounds = this.map.getBounds();
        const zoom = this.map.getZoom();
        
        // Preload tiles for current view and nearby areas
        for (let z = Math.max(zoom - 1, 12); z <= Math.min(zoom + 1, 16); z++) {
            const tileBounds = this.getTileBounds(bounds, z);
            
            for (let x = tileBounds.minX; x <= tileBounds.maxX; x++) {
                for (let y = tileBounds.minY; y <= tileBounds.maxY; y++) {
                    const tileUrl = `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
                    // Throttle preloading to avoid lag
                    setTimeout(() => this.preloadTile(tileUrl), (x + y) % 20 * 50);
                }
            }
        }
    }

    getTileBounds(bounds, zoom) {
        const n = Math.pow(2, zoom);
        const west = bounds.getWest();
        const east = bounds.getEast();
        const south = bounds.getSouth();
        const north = bounds.getNorth();

        const minX = Math.floor(((west + 180) / 360) * n);
        const maxX = Math.floor(((east + 180) / 360) * n);
        const minY = Math.floor(((1 - Math.log(Math.tan(north * Math.PI / 180) + 1 / Math.cos(north * Math.PI / 180)) / Math.PI) / 2) * n);
        const maxY = Math.floor(((1 - Math.log(Math.tan(south * Math.PI / 180) + 1 / Math.cos(south * Math.PI / 180)) / Math.PI) / 2) * n);

        return { minX, maxX, minY, maxY };
    }

    async preloadTile(url) {
        try {
            const response = await fetch(url);
            if (response.ok) {
                const blob = await response.blob();
                
                // Ensure mapTiles is a Set
                if (!(this.localData.mapTiles instanceof Set)) {
                    this.localData.mapTiles = new Set();
                }
                this.localData.mapTiles.add(url);
                
                // Store in IndexedDB
                if ('indexedDB' in window) {
                    await this.storeTileInIndexedDB(url, blob);
                }
            }
        } catch (error) {
            console.error("Error preloading tile:", error);
        }
    }

    async storeTileInIndexedDB(url, blob) {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('EvacuationDB', 1);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                const db = request.result;
                const transaction = db.transaction(['mapTiles'], 'readwrite');
                const store = transaction.objectStore('mapTiles');
                
                const tileRequest = store.put({
                    url: url,
                    data: blob,
                    timestamp: Date.now()
                });
                
                tileRequest.onsuccess = () => resolve();
                tileRequest.onerror = () => reject(tileRequest.error);
            };
        });
    }

    updateStorageInfo() {
        // Ensure mapTiles is a Set
        if (!(this.localData.mapTiles instanceof Set)) {
            this.localData.mapTiles = new Set();
        }
        
        const tilesCount = this.localData.mapTiles.size || 0;
        document.getElementById('tilesStored').textContent = tilesCount.toLocaleString();
        document.getElementById('sheltersStored').textContent = this.localData.shelters ? this.localData.shelters.length : 0;
        document.getElementById('routesStored').textContent = this.localData.routes ? this.localData.routes.length : 0;
    }

    updateDataPanel() {
        const shelters = this.localData.shelters || [];
        const routes = this.localData.routes || [];
        
        const activeShelters = shelters.filter(s => s.is_active === 1);
        const safeShelters = activeShelters.filter(s => s.is_safe_shelter === 1);
        const availableShelters = safeShelters.filter(s => 
            parseInt(s.capacity || 0) > (s.current_occupants || 0)
        ).length;
        
        const totalCapacity = activeShelters.reduce((sum, s) => 
            sum + parseInt(s.capacity || 0), 0
        );
        
        const safeRoutes = routes.filter(r => r.is_safe).length;
        const activeAlerts = shelters.filter(s => 
            s.typhoon_zone === 'Yes' || s.flood_zone === 'Yes' || 
            s.landslide_zone === 'Yes' || s.storm_surge_zone === 'Yes'
        ).length;
        
        console.log("📊 Data Panel Update:", {
            totalShelters: shelters.length,
            activeShelters: activeShelters.length,
            safeShelters: safeShelters.length,
            availableShelters,
            totalCapacity,
            safeRoutes,
            activeAlerts,
            totalRoutes: routes.length
        });
        
        document.getElementById('availableShelters').textContent = availableShelters;
        document.getElementById('totalCapacity').textContent = totalCapacity.toLocaleString();
        document.getElementById('safeRoutes').textContent = safeRoutes;
        document.getElementById('activeAlerts').textContent = activeAlerts;
    }

    async syncData() {
        if (!this.isOnline) {
            this.showOfflineIndicator();
            return;
        }

        console.log("🔄 Starting data sync...");
        
        const syncProgress = document.getElementById('syncProgress');
        const syncPercentage = document.getElementById('syncPercentage');
        const syncProgressFill = document.getElementById('syncProgressFill');
        
        syncProgress.classList.add('show');
        
        try {
            // Simulate sync progress
            for (let i = 0; i <= 100; i += 10) {
                syncPercentage.textContent = `${i}%`;
                syncProgressFill.style.width = `${i}%`;
                await new Promise(resolve => setTimeout(resolve, 100));
            }

            // Fetch latest data from server
            await this.fetchLatestData();
            
            // Update last sync time
            this.lastSyncTime = Date.now();
            localStorage.setItem('lastSyncTime', this.lastSyncTime);
            
            // Update UI
            this.updateDataAge();
            this.updateDataPanel();
            
            console.log("✅ Data sync completed");
            
        } catch (error) {
            console.error("❌ Sync failed:", error);
        } finally {
            setTimeout(() => {
                syncProgress.classList.remove('show');
            }, 2000);
        }
    }

    async fetchLatestData() {
        try {
            // Fetch data from PHP export script
            const response = await fetch('export-offline-data.php');
            if (!response.ok) {
                throw new Error('Failed to fetch data from server');
            }
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.message || 'Server error');
            }
            
            console.log("📥 Received data from server:", {
                shelters: data.shelters ? data.shelters.length : 0,
                routes: data.routes ? data.routes.length : 0,
                dangerZones: data.dangerZones ? data.dangerZones.length : 0,
                barangays: data.barangays ? data.barangays.length : 0,
                totalShelters: data.totalShelters,
                totalRoutes: data.totalRoutes,
                totalDangerZones: data.totalDangerZones,
                totalBarangays: data.totalBarangays
            });
            
            // Update local data with fetched data
            this.localData.shelters = data.shelters || [];
            this.localData.routes = data.routes || [];
            this.localData.dangerZones = data.dangerZones || [];
            this.localData.barangays = data.barangays || [];
            
            // Store in localStorage
            localStorage.setItem('evacuationData', JSON.stringify(this.localData));
            
            // Store in IndexedDB
            if ('indexedDB' in window) {
                await this.storeDataInIndexedDB();
            }
            
            // Re-render map
            this.renderLocalData();
            
            console.log('✅ Data synced from database:', {
                shelters: data.totalShelters,
                routes: data.totalRoutes,
                dangerZones: data.totalDangerZones,
                barangays: data.totalBarangays
            });
            
        } catch (error) {
            console.error('❌ Failed to fetch data from server:', error);
            // Fallback to sample data
            console.log('📊 Loading fallback sample data...');
            await this.loadSampleData();
        }
    }

    async storeDataInIndexedDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('EvacuationDB', 1);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                const db = request.result;
                const transaction = db.transaction(['shelters', 'routes', 'dangerZones', 'barangays'], 'readwrite');
                
                // Store shelters
                const shelterStore = transaction.objectStore('shelters');
                if (this.localData.shelters) {
                    this.localData.shelters.forEach(shelter => {
                        try {
                            shelterStore.put(shelter);
                        } catch (error) {
                            console.error('Error storing shelter:', error, shelter);
                        }
                    });
                }
                
                // Store routes
                const routeStore = transaction.objectStore('routes');
                if (this.localData.routes) {
                    this.localData.routes.forEach(route => {
                        try {
                            routeStore.put(route);
                        } catch (error) {
                            console.error('Error storing route:', error, route);
                        }
                    });
                }
                
                // Store danger zones
                const dangerStore = transaction.objectStore('dangerZones');
                if (this.localData.dangerZones) {
                    this.localData.dangerZones.forEach(zone => {
                        try {
                            dangerStore.put(zone);
                        } catch (error) {
                            console.error('Error storing danger zone:', error, zone);
                        }
                    });
                }
                
                // Store barangays
                const barangayStore = transaction.objectStore('barangays');
                if (this.localData.barangays) {
                    this.localData.barangays.forEach(barangay => {
                        try {
                            barangayStore.put(barangay);
                        } catch (error) {
                            console.error('Error storing barangay:', error, barangay);
                        }
                    });
                }
                
                transaction.oncomplete = () => resolve();
                transaction.onerror = () => reject(transaction.error);
            };
        });
    }

    updateDataAge() {
        if (this.lastSyncTime) {
            const timeDiff = Math.floor((Date.now() - this.lastSyncTime) / 60000);
            document.getElementById('dataAge').textContent = `${timeDiff} min ago`;
        } else {
            document.getElementById('dataAge').textContent = 'Never';
        }
    }

    startPeriodicSync() {
        // Sync every 5 minutes when online
        setInterval(() => {
            if (this.isOnline) {
                this.syncData();
            }
        }, 5 * 60 * 1000);
    }

    updateUI() {
        this.updateDataPanel();
        this.updateDataAge();
        this.updateStorageInfo();
        
        // Update sync status
        const syncStatus = document.getElementById('syncStatus');
        if (this.isOnline) {
            syncStatus.className = 'status-badge status-syncing';
            syncStatus.innerHTML = '<i class="fas fa-sync-alt fa-spin"></i> Syncing';
        } else {
            syncStatus.className = 'status-badge status-offline';
            syncStatus.innerHTML = '<i class="fas fa-sync-alt"></i> Offline';
        }
    }

    toggleOfflineMode() {
        this.offlineMode = !this.offlineMode;
        const button = document.getElementById('offlineToggle');
        
        if (this.offlineMode) {
            button.innerHTML = '<i class="fas fa-wifi-slash"></i>';
            button.title = 'Switch to Online Mode';
            document.getElementById('offlineMode').textContent = 'Active';
        } else {
            button.innerHTML = '<i class="fas fa-wifi"></i>';
            button.title = 'Switch to Offline Mode';
            document.getElementById('offlineMode').textContent = 'Ready';
        }
    }

}

// Initialize the system when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log("🚀 Starting Enhanced Offline Evacuation System...");
    window.evacuationSystem = new EnhancedOfflineEvacuationSystem();
});

// Service Worker for offline functionality
if ('serviceWorker' in navigator) {
    navigator.serviceWorker
        .register('/sw.js') // ✅ dapat ganito
        .then(() => console.log('🛠️ Service Worker (sw.js) registered successfully!'))
        .catch(err => console.error('❌ Service Worker registration failed:', err));
}
