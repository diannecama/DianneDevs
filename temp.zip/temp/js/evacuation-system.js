// Random Forest Machine Learning Implementation
class RandomForest {
    constructor(nTrees = 20, maxDepth = 5, randomState = 42) {
        this.nTrees = nTrees;
        this.maxDepth = maxDepth;
        this.randomState = randomState;
        this.trees = [];
        this.featureImportance = {};
        this.isTrained = false;
        this.batchSize = 5; // Train trees in batches to prevent blocking
    }

    // Train the Random Forest model (Optimized)
    train(X, y) {
        // Initialize feature importance
        const features = Object.keys(X[0]);
        features.forEach(feature => {
            this.featureImportance[feature] = 0;
        });

        // Train trees in batches to prevent blocking
        this.trainTreesBatch(X, y, 0);
        
        return this;
    }

    // Train trees in batches
    trainTreesBatch(X, y, startIndex) {
        const endIndex = Math.min(startIndex + this.batchSize, this.nTrees);
        
        for (let i = startIndex; i < endIndex; i++) {
            // Bootstrap sampling (random subset of data)
            const bootstrapSample = this.bootstrapSample(X, y);
            
            // Create decision tree with random feature selection
            const tree = new DecisionTree(this.maxDepth, this.randomState + i);
            tree.train(bootstrapSample.X, bootstrapSample.y);
            
            this.trees.push(tree);
        }

        // Continue with next batch if needed
        if (endIndex < this.nTrees) {
            setTimeout(() => {
                this.trainTreesBatch(X, y, endIndex);
            }, 10);
        } else {
            this.isTrained = true;
        }
    }

    // Predict evacuation risk
    predict(X) {
        if (!this.isTrained) {
            throw new Error('Random Forest must be trained before making predictions');
        }

        const predictions = [];
        
        // Get prediction from each tree
        this.trees.forEach(tree => {
            const prediction = tree.predict(X);
            predictions.push(prediction);
        });

        // Majority voting for classification
        const riskVotes = this.countVotes(predictions);
        const finalPrediction = this.getMajorityVote(riskVotes);
        
        return {
            prediction: finalPrediction,
            confidence: this.calculateConfidence(riskVotes),
            featureImportance: this.featureImportance,
            treeVotes: riskVotes
        };
    }

    // Bootstrap sampling
    bootstrapSample(X, y) {
        const nSamples = X.length;
        const bootstrapX = [];
        const bootstrapY = [];

        for (let i = 0; i < nSamples; i++) {
            const randomIndex = Math.floor(Math.random() * nSamples);
            bootstrapX.push(X[randomIndex]);
            bootstrapY.push(y[randomIndex]);
        }

        return { X: bootstrapX, y: bootstrapY };
    }

    // Count votes from all trees
    countVotes(predictions) {
        const votes = { 'LOW': 0, 'MEDIUM': 0, 'HIGH': 0, 'CRITICAL': 0 };
        
        predictions.forEach(prediction => {
            votes[prediction]++;
        });

        return votes;
    }

    // Get majority vote
    getMajorityVote(votes) {
        let maxVotes = 0;
        let majorityVote = 'LOW';

        Object.entries(votes).forEach(([risk, count]) => {
            if (count > maxVotes) {
                maxVotes = count;
                majorityVote = risk;
            }
        });

        return majorityVote;
    }

    // Calculate prediction confidence
    calculateConfidence(votes) {
        const totalVotes = Object.values(votes).reduce((sum, count) => sum + count, 0);
        const maxVotes = Math.max(...Object.values(votes));
        
        return (maxVotes / totalVotes) * 100;
    }
}

// Decision Tree Implementation
class DecisionTree {
    constructor(maxDepth, randomState) {
        this.maxDepth = maxDepth;
        this.randomState = randomState;
        this.tree = null;
    }

    train(X, y) {
        this.tree = this.buildTree(X, y, 0);
    }

    buildTree(X, y, depth) {
        // Stopping criteria
        if (depth >= this.maxDepth || this.isPure(y) || X.length <= 1) {
            return { type: 'leaf', prediction: this.getMostCommon(y) };
        }

        // Find best split
        const split = this.findBestSplit(X, y);
        
        if (!split) {
            return { type: 'leaf', prediction: this.getMostCommon(y) };
        }

        // Split data
        const { leftX, leftY, rightX, rightY } = this.splitData(X, y, split);

        // Recursively build subtrees
        return {
            type: 'node',
            feature: split.feature,
            threshold: split.threshold,
            left: this.buildTree(leftX, leftY, depth + 1),
            right: this.buildTree(rightX, rightY, depth + 1)
        };
    }

    findBestSplit(X, y) {
        const features = Object.keys(X[0]);
        let bestSplit = null;
        let bestGini = Infinity;

        // Random feature selection (Random Forest characteristic)
        const randomFeatures = this.getRandomFeatures(features, Math.ceil(Math.sqrt(features.length)));

        randomFeatures.forEach(feature => {
            const values = X.map(sample => sample[feature]).sort((a, b) => a - b);
            const thresholds = this.getThresholds(values);

            thresholds.forEach(threshold => {
                const gini = this.calculateGini(X, y, feature, threshold);
                
                if (gini < bestGini) {
                    bestGini = gini;
                    bestSplit = { feature, threshold, gini };
                }
            });
        });

        return bestSplit;
    }

    getRandomFeatures(features, n) {
        const shuffled = [...features].sort(() => 0.5 - Math.random());
        return shuffled.slice(0, n);
    }

    getThresholds(values) {
        const thresholds = [];
        for (let i = 0; i < values.length - 1; i++) {
            thresholds.push((values[i] + values[i + 1]) / 2);
        }
        return thresholds;
    }

    calculateGini(X, y, feature, threshold) {
        const { leftY, rightY } = this.splitData(X, y, { feature, threshold });
        
        const leftGini = this.giniImpurity(leftY);
        const rightGini = this.giniImpurity(rightY);
        
        const leftWeight = leftY.length / y.length;
        const rightWeight = rightY.length / y.length;
        
        return leftWeight * leftGini + rightWeight * rightGini;
    }

    giniImpurity(y) {
        const counts = {};
        y.forEach(label => {
            counts[label] = (counts[label] || 0) + 1;
        });

        const total = y.length;
        let gini = 1;
        
        Object.values(counts).forEach(count => {
            const prob = count / total;
            gini -= prob * prob;
        });

        return gini;
    }

    splitData(X, y, split) {
        const leftX = [], leftY = [], rightX = [], rightY = [];

        X.forEach((sample, index) => {
            if (sample[split.feature] <= split.threshold) {
                leftX.push(sample);
                leftY.push(y[index]);
            } else {
                rightX.push(sample);
                rightY.push(y[index]);
            }
        });

        return { leftX, leftY, rightX, rightY };
    }

    isPure(y) {
        return new Set(y).size === 1;
    }

    getMostCommon(y) {
        const counts = {};
        y.forEach(label => {
            counts[label] = (counts[label] || 0) + 1;
        });

        let maxCount = 0;
        let mostCommon = y[0];

        Object.entries(counts).forEach(([label, count]) => {
            if (count > maxCount) {
                maxCount = count;
                mostCommon = label;
            }
        });

        return mostCommon;
    }

    predict(X) {
        if (Array.isArray(X)) {
            // Single sample prediction
            return this.predictSample(X);
        } else {
            // Multiple samples prediction
            return X.map(sample => this.predictSample(sample));
        }
    }

    predictSample(sample) {
        let node = this.tree;

        while (node.type === 'node') {
            if (sample[node.feature] <= node.threshold) {
                node = node.left;
            } else {
                node = node.right;
            }
        }

        return node.prediction;
    }
}


// Evacuation System - Main JavaScript File
class EvacuationSystem {
    constructor() {
        this.map = null;
        this.shelters = [];
        this.currentLocation = null;
        this.isOnline = navigator.onLine;
        this.routingControl = null;
        this.currentRoute = null;
        this.geolocationWatchId = null;
        this.geolocationAccuracy = null;
        this.geoJSONLayers = [];
        this.floodMode = false;
        this.floodZones = [];
        this.autoSearchTimeout = null;
        
        // Random Forest Machine Learning Model (Optimized)
        this.randomForest = new RandomForest(20, 5, 42); // Reduced trees and depth for speed
        this.mlModel = null;
        this.trainingData = [];
        this.isModelTrained = false;
        this.trainingInProgress = false;
        
        this.init();
    }

    async init() {
        this.initMap();
        await this.loadOfflineData();
        await this.loadCurrentLocation();
        this.setupEventListeners();
        this.startSync();
        
        // Initialize Random Forest model with evacuation data (Async to avoid blocking)
        setTimeout(() => {
            this.initializeRandomForest();
        }, 2000); // Delay training by 2 seconds
        
        // Check location status and provide feedback
        this.checkLocationStatus();
        
        // Set up periodic location status checks (reduced frequency)
        setInterval(() => {
            this.checkLocationStatus();
        }, 120000); // Check every 2 minutes instead of 30 seconds
        
        // Show welcome message for multi-device system
        this.showWelcomeMessage();
    }

    initMap() {
        this.map = L.map('map', {
            center: [13.5503, 124.2054], // Virac, Catanduanes coordinates
            zoom: 12,
            zoomControl: true,
            attributionControl: false,
            preferCanvas: true, // Use canvas for better performance
            renderer: L.canvas({ tolerance: 5 }), // Better rendering performance
            fadeAnimation: false, // Disable fade for faster rendering
            zoomAnimation: true,
            markerZoomAnimation: false // Disable marker animation for speed
        });

        // Multiple tile layer options for offline/online fallback
        this.tileLayers = {
            online: {
                dark: L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                    attribution: '©OpenStreetMap, ©CartoDB',
                    subdomains: 'abcd',
                    maxZoom: 19
                }),
                light: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '©OpenStreetMap contributors',
                    maxZoom: 19
                }),
                satellite: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                    attribution: '©Esri',
                    maxZoom: 19
                })
            },
            offline: {
                dark: L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                    attribution: '©OpenStreetMap, ©CartoDB',
                    subdomains: 'abcd',
                    maxZoom: 19
                }),
                light: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '©OpenStreetMap contributors',
                    maxZoom: 19
                })
            }
        };

        // Start with light theme
        this.currentTileLayer = this.tileLayers.online.light;
        this.currentTileLayer.addTo(this.map);

        this.addMapControls();
        this.setupOfflineDetection();
    }

    
    setupOfflineDetection() {
        // Check if we're online and switch tile layers accordingly
        if (navigator.onLine) {
            this.switchToOnlineMode();
        } else {
            this.switchToOfflineMode();
        }

        // Listen for online/offline events
        window.addEventListener('online', () => {
            this.switchToOnlineMode();
        });

        window.addEventListener('offline', () => {
            this.switchToOfflineMode();
        });
    }

    switchToOnlineMode() {
        if (this.currentTileLayer && this.map.hasLayer(this.currentTileLayer)) {
            this.map.removeLayer(this.currentTileLayer);
        }
        this.currentTileLayer = this.tileLayers.online.light;
        this.currentTileLayer.addTo(this.map);
        this.updateConnectionStatus(true);
    }

    switchToOfflineMode() {
        if (this.currentTileLayer && this.map.hasLayer(this.currentTileLayer)) {
            this.map.removeLayer(this.currentTileLayer);
        }
        this.currentTileLayer = this.tileLayers.offline.light;
        this.currentTileLayer.addTo(this.map);
        this.updateConnectionStatus(false);
    }

    /* STATUS */
    updateConnectionStatus(isOnline) {
        const statusControl = document.getElementById('connectionStatusControl');
        if (statusControl) {
            if (isOnline) {
                statusControl.innerHTML = `
                    <a href="#" title="Connection Status" style="background: #28a745; color: white; margin-bottom: 0px; padding: 0; text-decoration: none; border-radius: 4px; font-size: 12px; display: block;">
                        <i class="fas fa-wifi"></i>
                    </a>
                `;
            } else {
                statusControl.innerHTML = `
                    <a href="#" title="Connection Status" style="background: #dc3545; color: white; margin-bottom: 0px; padding: 0; text-decoration: none; border-radius: 4px; font-size: 12px; display: block;">
                        <i class="fas fa-wifi-slash"></i>
                    </a>
                `;
            }
        }
    }
    /* SATELLITE LAYER */
    addMapControls() {
        // Create base layers for different map styles
        const baseLayers = {
            'Light Theme': this.tileLayers.online.light,
            'Dark Theme': this.tileLayers.online.dark,
            'Satellite': this.tileLayers.online.satellite
        };


        // Add custom controls
        this.addCustomControls();
    }

    /* STATUS LAYER */
    addCustomControls() {
        // Add a custom control for offline/online status
        const OnlineStatusControl = L.Control.extend({
            onAdd: function(map) {
                const container = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
                container.innerHTML = `
                    <a href="#" title="Connection Status" style="background: #28a745; color: white; padding: 0; text-decoration: none; border-radius: 4px; font-size: 12px; display: block;">
                        <i class="fas fa-wifi"></i> Online
                    </a>
                `;
                container.id = 'connectionStatusControl';
                return container;
            }
        });

        // Add custom controls with proper spacing
        this.addCustomControlsWithSpacing();
    }

    addCustomControlsWithSpacing() {
        // Create OnlineStatusControl
        const OnlineStatusControl = L.Control.extend({
            onAdd: function(map) {
                const container = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
                container.innerHTML = `
                    <a href="#" title="Connection Status" style="background: #28a745; color: white; padding: 0; text-decoration: none; border-radius: 4px; font-size: 12px; display: block;">
                        <i class="fas fa-wifi"></i> Online
                    </a>
                `;
                container.id = 'connectionStatusControl';
                return container;
            }
        });

        
        // Add online status control
        this.onlineStatusControl = new OnlineStatusControl({ position: 'topleft' });
        this.onlineStatusControl.addTo(this.map);

         /* THEME LAYER */

        // Add theme control with custom positioning
        const ThemeControl = L.Control.extend({
            onAdd: function(map) {
                const container = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
                container.innerHTML = `
                    <a href="#" title="Switch Theme" style="background: #6c757d; color: white; padding: 0; text-decoration: none; border-radius: 4px; font-size: 12px; display: none;">
                        <i class="fas fa-palette"></i>
                    </a>
                `;
                container.id = 'themeControl';
                container.style.marginTop = '10px';
                
                // Add click event
                container.addEventListener('click', function(e) {
                    e.preventDefault();
                    evacuationSystem.cycleMapTheme();
                });
                
                return container;
            }
        });

        /* DOWNLOAD MAP LAYER */

        this.themeControl = new ThemeControl({ position: 'topleft' });
        this.themeControl.addTo(this.map);

        // Add offline download control with custom positioning
        const OfflineDownloadControl = L.Control.extend({
            onAdd: function(map) {
                const container = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
                container.innerHTML = `
                    <a href="#" id="downloadOfflineBtn" title="Download Map for Offline Use" style="background: #007bff; color: white; padding: 0; text-decoration: none; border-radius: 4px; font-size: 12px; display: block;">
                        <i class="fas fa-download"></i>
                    </a>
                `;
                container.id = 'offlineDownloadControl';
                container.style.marginTop = '10px';
                
                // Add click event
                container.addEventListener('click', function(e) {
                    e.preventDefault();
                    evacuationSystem.downloadForOfflineUse();
                });
                
                return container;
            }
        });

        this.offlineDownloadControl = new OfflineDownloadControl({ position: 'topleft' });
        this.offlineDownloadControl.addTo(this.map);
    }

    cycleMapTheme() {
        const themes = ['dark', 'light', 'satellite'];
        const currentTheme = this.getCurrentTheme();
        const currentIndex = themes.indexOf(currentTheme);
        const nextIndex = (currentIndex + 1) % themes.length;
        const nextTheme = themes[nextIndex];
        
        this.switchMapTheme(nextTheme);
    }

    getCurrentTheme() {
        if (this.currentTileLayer === this.tileLayers.online.dark || this.currentTileLayer === this.tileLayers.offline.dark) {
            return 'dark';
        } else if (this.currentTileLayer === this.tileLayers.online.light || this.currentTileLayer === this.tileLayers.offline.light) {
            return 'light';
        } else {
            return 'satellite';
        }
    }

    switchMapTheme(theme) {
        if (this.currentTileLayer && this.map.hasLayer(this.currentTileLayer)) {
            this.map.removeLayer(this.currentTileLayer);
        }

        const isOnline = navigator.onLine;
        const layerGroup = isOnline ? this.tileLayers.online : this.tileLayers.offline;

        switch (theme) {
            case 'dark':
                this.currentTileLayer = layerGroup.dark;
                break;
            case 'light':
                this.currentTileLayer = layerGroup.light;
                break;
            case 'satellite':
                this.currentTileLayer = isOnline ? layerGroup.satellite : layerGroup.dark;
                break;
            default:
                this.currentTileLayer = layerGroup.dark;
        }

        this.currentTileLayer.addTo(this.map);
    }

    async downloadForOfflineUse() {
        if (!navigator.onLine) {
            this.showNotification('You need to be online to download map tiles', 'warning');
            return;
        }

        const downloadBtn = document.getElementById('downloadOfflineBtn');
        if (downloadBtn) {
            downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Downloading...';
            downloadBtn.style.background = '#ffc107';
        }

        try {
            this.showNotification('📥 Downloading map tiles for offline use... Hintayin lang po.', 'info');
            
            // Get current map bounds and zoom
            const bounds = this.map.getBounds();
            const currentZoom = this.map.getZoom();
            
            // Preload tiles for current view and nearby zoom levels
            let tileCount = 0;
            const promises = [];
            
            for (let zoom = Math.max(currentZoom - 1, 10); zoom <= Math.min(currentZoom + 2, 16); zoom++) {
                const tileBounds = this.getTileBounds(bounds, zoom);
                
                for (let x = tileBounds.minX; x <= tileBounds.maxX; x++) {
                    for (let y = tileBounds.minY; y <= tileBounds.maxY; y++) {
                        const tileUrl = `https://tile.openstreetmap.org/${zoom}/${x}/${y}.png`;
                        
                        // Throttle requests to avoid overwhelming the server
                        const delay = tileCount * 50; // 50ms delay between requests
                        promises.push(
                            new Promise(resolve => {
                                setTimeout(() => {
                                    fetch(tileUrl)
                                        .then(response => {
                                            resolve();
                                        })
                                        .catch(() => resolve());
                                }, delay);
                            })
                        );
                        
                        tileCount++;
                    }
                }
            }
            
            await Promise.all(promises);
            
            this.showNotification(`✅ Successfully downloaded ${tileCount} map tiles! Pwede mo na gamitin offline.`, 'success');
            
            if (downloadBtn) {
                downloadBtn.innerHTML = '<i class="fas fa-check"></i> Downloaded';
                downloadBtn.style.background = '#28a745';
                
                setTimeout(() => {
                    downloadBtn.innerHTML = '<i class="fas fa-download"></i> Offline';
                    downloadBtn.style.background = '#007bff';
                }, 3000);
            }
            
        } catch (error) {
            console.error('Error downloading tiles:', error);
            this.showNotification('❌ Error downloading map tiles. Please try again.', 'danger');
            
            if (downloadBtn) {
                downloadBtn.innerHTML = '<i class="fas fa-download"></i> Offline';
                downloadBtn.style.background = '#007bff';
            }
        }
    }

    getTileBounds(bounds, zoom) {
        const n = Math.pow(2, zoom);
        
        const latToTile = (lat) => {
            return Math.floor((1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * n);
        };
        
        const lngToTile = (lng) => {
            return Math.floor((lng + 180) / 360 * n);
        };
        
        return {
            minX: lngToTile(bounds.getWest()),
            maxX: lngToTile(bounds.getEast()),
            minY: latToTile(bounds.getNorth()),
            maxY: latToTile(bounds.getSouth())
        };
    }

    async loadOfflineData() {
        try {
            // First try to load from JSON file
            const response = await fetch('data/shelters_offline.min.json');
            if (response.ok) {
                const jsonData = await response.json();
                this.shelters = jsonData.shelters || [];
                
                // Clean up invalid coordinates
                this.shelters = this.cleanInvalidCoordinates(this.shelters);
                
                this.displayShelters();
                return;
            }
        } catch (error) {
           
        }
        
        // Fallback to localStorage
        try {
            const offlineData = localStorage.getItem('evacuationData');
            if (offlineData) {
                this.shelters = JSON.parse(offlineData);
                
                // Clean up invalid coordinates
                this.shelters = this.cleanInvalidCoordinates(this.shelters);
                
                this.displayShelters();
            }
        } catch (error) {
            console.error('Error loading offline data:', error);
        }
    }
    
    cleanInvalidCoordinates(shelters) {
        const validShelters = [];
        const invalidShelters = [];
        
        shelters.forEach(shelter => {
            const lat = parseFloat(shelter.latitude);
            const lng = parseFloat(shelter.longitude);
            
            // Check for invalid coordinates
            if (!Number.isFinite(lat) || !Number.isFinite(lng) || 
                lat < -90 || lat > 90 || lng < -180 || lng > 180 ||
                lat === 0 && lng === 0 || // Avoid 0,0 coordinates
                lat === 999.99999999 || lng === 999.99999999 || // Common placeholder values
                Math.abs(lat) === 999 || Math.abs(lng) === 999) { // Another common placeholder
                
                invalidShelters.push({
                    owner: shelter.owner_name,
                    barangay: shelter.barangay,
                    lat: shelter.latitude,
                    lng: shelter.longitude
                });
            } else {
                validShelters.push(shelter);
            }
        });
        return validShelters;
    }
    
    async loadCurrentLocation() {
    try {
        const response = await fetch('app/apiCurrentLocation.php');
        if (response.ok) {
            const data = await response.json();
            if (data.success && data.data) {
                this.currentLocation = {
                    lat: parseFloat(data.data.latitude),
                    lng: parseFloat(data.data.longitude),
                    timestamp: data.data.updated_at || data.data.created_at
                };

                // Zoom to current location
                this.map.setView([this.currentLocation.lat, this.currentLocation.lng], 15);

                // Add user location marker
                this.addSavedLocationMarker();

                // Update nearest shelters panel
                this.updateNearestShelters();

                // Show success message
                const shelterInfo = document.getElementById('nearestShelters');
                const timestamp = this.currentLocation.timestamp ? new Date(this.currentLocation.timestamp).toLocaleString() : '';
                shelterInfo.innerHTML = `
                    <div class="shelter-info">
                        <h6><i class="fas fa-check-circle"></i> Location Loaded</h6>
                        <p class="text-muted">Using saved location from database</p>
                        <div class="mt-2">
                            <small class="text-muted">Last updated: ${timestamp}</small>
                        </div>
                        <div class="mt-2">
                            <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary btn-sm w-100 mb-2">
                                <i class="fas fa-location-arrow"></i> Update Location
                            </button>
                        </div>
                    </div>
                `;
            } else {
                throw new Error('Failed to fetch location');
            }
        }
    } catch (err) {
        console.error('Error loading location:', err);
        // Fallback default location
        this.currentLocation = { lat: 13.5568, lng: 124.1998, timestamp: new Date().toISOString() };
        this.map.setView([this.currentLocation.lat, this.currentLocation.lng], 12);
        this.addSavedLocationMarker();
        this.updateNearestShelters();
    }
}

    addSavedLocationMarker() {
        if (!this.currentLocation) return;

        // Remove existing saved marker if any
        if (this.savedLocationMarker) {
            this.map.removeLayer(this.savedLocationMarker);
        }

        // Add new saved location marker
        // Validate coordinates before creating marker
        const lat = parseFloat(this.currentLocation.lat);
        const lng = parseFloat(this.currentLocation.lng);

        this.savedLocationMarker = L.marker([lat, lng], {
            icon: L.divIcon({
                className: 'saved-location-marker',
                html: '<div style="background-color: #6f42c1; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-size: 10px; font-weight: bold;">S</div>',
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            })
        }).addTo(this.map);

        // Add popup with saved location info
        this.savedLocationMarker.bindPopup(`
            <div class="custom-popup">
                <div class="popup-title">Saved Location</div>
                <div class="popup-info">Latitude: ${this.currentLocation.lat.toFixed(6)}</div>
                <div class="popup-info">Longitude: ${this.currentLocation.lng.toFixed(6)}</div>
                <div class="popup-info">From database</div>
                <button onclick="evacuationSystem.showLocationHistory()" style="background: #6f42c1; color: white; border: none; padding: 5px 10px; border-radius: 4px; margin-top: 10px; cursor: pointer;">
                    📍 View History
                </button>
            </div>
        `).openPopup();
    }

    async showLocationHistory() {
        try {
            const response = await fetch('app/getLocationHistory.php');
            const data = await response.json();

            if (data.success && data.data.length > 0) {
                const shelterInfo = document.getElementById('nearestShelters');
                let html = `
                    <div class="shelter-info">
                        <h6><i class="fas fa-history"></i> Location History</h6>
                        <div class="database-data-container">
                `;

                data.data.forEach((location, index) => {
                    const isCurrent = index === 0;
                    const statusClass = isCurrent ? 'safe' : 'location';
                    const statusText = isCurrent ? 'Current' : 'Previous';
                    
                    html += `
                        <div class="data-item ${statusClass}" onclick="evacuationSystem.selectLocationFromHistory(${location.latitude}, ${location.longitude})">
                            <div style="font-weight: bold; color: #fff; margin-bottom: 5px;">
                                ${statusText} Location ${isCurrent ? '⭐' : ''}
                            </div>
                            <div style="font-size: 12px; color: #ccc;">
                                <div><strong>ID:</strong> ${location.id}</div>
                                <div><strong>Coordinates:</strong> ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}</div>
                                <div><strong>Created:</strong> ${new Date(location.created_at).toLocaleString()}</div>
                                ${location.updated_at ? `<div><strong>Updated:</strong> ${new Date(location.updated_at).toLocaleString()}</div>` : ''}
                            </div>
                        </div>
                    `;
                });

                html += `
                        </div>
                        <button class="btn btn-outline-light btn-sm w-100 mt-2" onclick="evacuationSystem.updateNearestShelters()">
                            <i class="fas fa-times"></i> Close History
                        </button>
                    </div>
                `;

                shelterInfo.innerHTML = html;
            } else {
                const shelterInfo = document.getElementById('nearestShelters');
                shelterInfo.innerHTML = `
                    <div class="shelter-info">
                        <h6><i class="fas fa-info-circle"></i> No Location History</h6>
                        <p class="text-muted">No location history found in database.</p>
                    </div>
                `;
            }
        } catch (error) {
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-exclamation-triangle"></i> Error</h6>
                    <p class="text-muted">Failed to load location history.</p>
                </div>
            `;
        }
    }

    selectLocationFromHistory(latitude, longitude) {
        this.currentLocation = { lat: latitude, lng: longitude };
        // Center map on selected location
        this.map.setView([latitude, longitude], 15);
        // Update marker
        this.addSavedLocationMarker();
        // Update nearest shelters
        this.updateNearestShelters();
    }
    
    displaySavedLocation(locationData) {
        // Validate coordinates before creating marker
        const lat = parseFloat(locationData.latitude);
        const lng = parseFloat(locationData.longitude);
        // Add saved location marker to map
        const savedLocationMarker = L.marker([lat, lng], {
            icon: L.divIcon({
                className: 'saved-location-marker',
                html: '<div style="background-color: #6f42c1; width: 25px; height: 25px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: bold;">S</div>',
                iconSize: [25, 25],
                iconAnchor: [12.5, 12.5]
            })
        }).addTo(this.map);
        
        // Mark this as a saved location marker so it won't be removed when shelters are redrawn
        savedLocationMarker._savedLocationMarker = true;
        
        savedLocationMarker.bindPopup(`
            <div class="custom-popup">
                <h6 class="popup-title">Saved Location</h6>
                <div class="popup-info"><strong>Coordinates:</strong> ${locationData.latitude}, ${locationData.longitude}</div>
                <div class="popup-info"><strong>Saved:</strong> ${new Date(locationData.created_at).toLocaleString()}</div>
                <button onclick="evacuationSystem.showRouteToSavedLocation(${locationData.latitude}, ${locationData.longitude})" style="background: #6f42c1; color: white; border: none; padding: 5px 10px; border-radius: 4px; margin-top: 10px; cursor: pointer;">
                    🗺️ Show Route
                </button>
            </div>
        `);
        
        // Add click event for routing
        savedLocationMarker.on('click', () => {
            this.showRouteToSavedLocation(locationData.latitude, locationData.longitude);
        });
        
    }

    async fetchData() {
        try {
            // Try API first
            const response = await fetch('controllers/offline_api_controller.php?action=shelters');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            const data = await response.json();
            
            if (data.success) {
                this.shelters = data.data;
                // Save to localStorage for offline use
                localStorage.setItem('evacuationData', JSON.stringify(this.shelters));
                localStorage.setItem('lastSync', Date.now());
                return data.data;
            } else {
                throw new Error(data.error || 'Failed to fetch data');
            }
        } catch (error) {
            // Fallback to JSON file
            try {
                const jsonResponse = await fetch('data/shelters_offline.min.json');
                if (jsonResponse.ok) {
                    const jsonData = await jsonResponse.json();
                    this.shelters = jsonData.shelters || [];
                    return this.shelters;
                }
            } catch (jsonError) {
                console.error('Error loading shelters from JSON file:', jsonError);
            }
            
            // Final fallback to localStorage
            const offlineData = localStorage.getItem('evacuationData');
            if (offlineData) {
                this.shelters = JSON.parse(offlineData);
                return this.shelters;
            }
            
            console.error('Error fetching shelters:', error);
            throw error;
        }
    }

    async syncData() {
        try {
            if (!this.isOnline) {
                return;
            }

            const data = await this.fetchData();
            this.displayShelters();
            this.updateStatus('Online', 'online');
        } catch (error) {
            console.error('Sync failed:', error);
            this.updateStatus('Offline', 'offline');
        }
    }

    displayShelters() {
        // Clear existing shelter markers only (preserve saved location marker and routes)
        this.map.eachLayer((layer) => {
        if (layer instanceof L.Marker && !layer._savedLocationMarker && !layer._isRoute) {
            this.map.removeLayer(layer);
        }
        });
        this.shelters.forEach(shelter => {
        const lat = parseFloat(shelter.latitude);
        const lng = parseFloat(shelter.longitude);
        // Default color
        let color = '#008037'; // Deep Green (Default)
        let iconSize = [28, 28];
        // Extract numeric value from capacity string
        const capacityStr = String(shelter.capacity || '0');
        const numericCapacity = parseInt(capacityStr.replace(/[^\d]/g, '')) || 0;
        // Capacity color logic
        if (numericCapacity >= 1 && numericCapacity <= 15) {
            color = '#008037'; 
        } else if (numericCapacity >= 16 && numericCapacity <= 50) {
            color = '#F4A300'; 
        } else if (numericCapacity > 50) {
            color = '#dc3545';
        }
        // Custom SVG marker (green with white circle)
        const svgIcon = `
            <svg xmlns="http://www.w3.org/2000/svg" width="${iconSize[0]}" height="${iconSize[1]}" viewBox="0 0 24 24">
                <path d="M12 2C8.14 2 5 5.14 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.86-3.14-7-7-7z" fill="${color}"/>
                <circle cx="12" cy="9" r="3" fill="#ffffff"/>
            </svg>
        `;
        const customIcon = L.divIcon({
            className: 'custom-marker',
            html: svgIcon,
            iconSize: iconSize,
            iconAnchor: [iconSize[0] / 2, iconSize[1]]
        });
            const marker = L.marker([lat, lng], { icon: customIcon }).addTo(this.map);
            // Popup on click
            marker.on('click', () => {
                marker.bindPopup(this.createShelterPopup(shelter)).openPopup();
                this.showShelterInfo(shelter);
            });
        });
        this.updateNearestShelters();
    }

    createShelterPopup(shelter) {
        const riskColor = this.getRiskColor(shelter.risk_level || 'Low');
        return `
            <div class="custom-popup">
                <h6 class="popup-title">${shelter.barangay || ''} Shelter</h6>
                <div class="popup-info"><strong>Owner:</strong> ${shelter.owner_name || ''}</div>
                <div class="popup-info"><strong>Barangay:</strong> ${shelter.barangay || ''}</div>
                <div class="popup-info"><strong>Capacity:</strong> ${shelter.capacity || 0}</div>
                <div class="popup-info"><strong>Elevation:</strong> ${shelter.elevation || 0}m</div>
                <div class="popup-info">
                    <strong>Hazard Zones:</strong><br>
                    🌪️ Typhoon: ${shelter.typhoon_zone || 'No'} | 🌊 Flood: ${shelter.flood_zone || 'No'}<br>
                    ⛰️ Landslide: ${shelter.landslide_zone || 'No'} | 🟫💧 Liquefaction: ${shelter.liquefaction_zone || 'No'}<br>
                    🌊 Storm Surge: ${shelter.storm_surge_zone || 'No'}
                </div>
                <div class="popup-info">
                    <strong>Risk Level:</strong> <span style="color: ${riskColor}; font-weight: bold;">${shelter.risk_level || 'Low'}</span>
                </div>
                <div class="popup-info">
                    <strong>Building:</strong> ${shelter.building_material_type || ''} | ${shelter.building_condition || ''}
                </div>
                <div class="popup-info">
                    <strong>Utilities:</strong> 💧 ${shelter.water_supply || ''} | ⚡ ${shelter.electricity || ''}
                </div>
                <div class="popup-info">
                    <strong>Access:</strong> 🛣️ ${shelter.road_condition || ''} | ⏱️ ${shelter.estimated_travel_time || 0}min
                </div>
                <div class="popup-info">
                    <strong>Features:</strong> 
                    ${shelter.near_main_road ? '🛣️ Near Main Road' : '🚶‍♂️ Remote Location'} 
                    ${shelter.is_safe_shelter ? '✅ Safe Shelter' : '⚠️ Needs Assessment'}
                </div>
                <div class="popup-info">
                    <strong>Status:</strong> 
                    ${shelter.is_active ? '🟢 Active' : '🔴 Inactive'}
                </div>
            </div>
        `;
    }

    showShelterInfo(shelter) {
        // Extract numeric value from capacity string
        const capacityStr = String(shelter.capacity || '0');
        const numericCapacity = parseInt(capacityStr.replace(/[^\d]/g, '')) || 0;
        
        let capacityClass = 'capacity-low';
        if (numericCapacity >= 1 && numericCapacity <= 15) capacityClass = 'capacity-medium';
        else if (numericCapacity >= 16) capacityClass = 'capacity-low';

        const riskColor = this.getRiskColor(shelter.risk_level || 'Low');
        const shelterInfo = document.getElementById('nearestShelters');
        shelterInfo.innerHTML = `
            <div class="shelter-info">
                <h6><i class="fas fa-home"></i> ${shelter.barangay || ''} Shelter</h6>
                <p><strong>Owner:</strong> ${shelter.owner_name || ''}</p>
                <p><strong>Barangay:</strong> ${shelter.barangay || ''}</p>
                <p><strong>Capacity:</strong> ${numericCapacity}</p>
                <div class="capacity-bar">
                    <div class="capacity-fill ${capacityClass}" style="width: ${Math.min(numericCapacity / 2, 100)}%"></div>
                </div>
                <p><strong>Elevation:</strong> ${shelter.elevation || 0}m</p>
                <p><strong>Risk Level:</strong> <span style="color: ${riskColor}; font-weight: bold;">${shelter.risk_level || 'Low'}</span></p>
                <p><strong>Hazard Zones:</strong><br>
                    🌪️ Typhoon: ${shelter.typhoon_zone || 'No'} | 🌊 Flood: ${shelter.flood_zone || 'No'}<br>
                    ⛰️ Landslide: ${shelter.landslide_zone || 'No'} | 🟫💧 Liquefaction: ${shelter.liquefaction_zone || 'No'}<br>
                    🌊 Storm Surge: ${shelter.storm_surge_zone || 'No'}
                </p>
                <p><strong>Building:</strong> ${shelter.building_material_type || ''} | ${shelter.building_condition || ''}</p>
                <p><strong>Utilities:</strong> 💧 ${shelter.water_supply || ''} | ⚡ ${shelter.electricity || ''}</p>
                <p><strong>Access:</strong> 🛣️ ${shelter.road_condition || ''} | ⏱️ ${shelter.estimated_travel_time || 0}min</p>
                <p><strong>Features:</strong> 
                    ${shelter.near_main_road ? '🛣️ Near Main Road' : '🚶‍♂️ Remote'} 
                    ${shelter.is_safe_shelter ? '✅ Safe' : '⚠️ Needs Assessment'}
                </p>
                <button onclick="evacuationSystem.showRouteToShelter(${shelter.latitude}, ${shelter.longitude}, '${shelter.barangay}')" class="btn btn-primary w-100 mt-2">
                    🗺️ Show Route from Saved Location
                </button>
            </div>
        `;
    }

    updateNearestShelters() {
        if (!this.currentLocation) {
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <p class="text-muted">Click "Get My Location" to find nearby shelters</p>
            `;
            return;
        }

        // Calculate distances and sort shelters
        const sheltersWithDistance = this.shelters.map(shelter => {
            const distance = this.calculateDistance(
                this.currentLocation.lat,
                this.currentLocation.lng,
                shelter.latitude,
                shelter.longitude
            );
            return { ...shelter, distance };
        }).sort((a, b) => a.distance - b.distance);

        // Show nearest 3 shelters
        const nearestShelters = sheltersWithDistance.slice(0, 3);
        const shelterInfo = document.getElementById('nearestShelters');
        
        let html = '<h6><i class="fas fa-map-marker-alt"></i> Nearest Shelters</h6>';
        nearestShelters.forEach(shelter => {
            const safetyStatus = shelter.is_safe_shelter ? '✅ Safe' : '⚠️ Needs Assessment';
            const riskColor = this.getRiskColor(shelter.risk_level || 'Low');
            html += `
                <div class="shelter-info" style="cursor: pointer;" onclick="evacuationSystem.showShelterInfo(${JSON.stringify(shelter).replace(/"/g, '&quot;')})">
                    <strong>${shelter.barangay || ''} Shelter</strong><br>
                    <small class="text-muted">
                        ${shelter.distance.toFixed(1)} km away • ${shelter.capacity || 0} • 
                        <span style="color: ${riskColor};">${shelter.risk_level || 'Low'} Risk</span> • ${safetyStatus}
                    </small>
                    <div class="mt-2">
                        <small class="text-muted">
                            🌪️ ${shelter.typhoon_zone || 'No'} | 🌊 ${shelter.flood_zone || 'No'} | 
                            ⛰️ ${shelter.landslide_zone || 'No'} | 🟫💧 ${shelter.liquefaction_zone || 'No'} | 
                            🌊 ${shelter.storm_surge_zone || 'No'} 
                        </small>
                    </div>
                    <button onclick="evacuationSystem.showRouteToShelter(${shelter.latitude}, ${shelter.longitude}, '${shelter.barangay}'); event.stopPropagation();" class="btn btn-outline-primary btn-sm w-100 mt-2">
                        🗺️ Route from Saved Location
                    </button>
                </div>
            `;
        });
        
        shelterInfo.innerHTML = html;
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Radius of the Earth in km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    async getCurrentLocation() {
        if (!navigator.geolocation) {
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-exclamation-triangle"></i> Browser Not Supported</h6>
                    <p class="text-muted">Geolocation is not supported by this browser. Please use a modern browser with location services enabled.</p>
                </div>
            `;
            return;
        }

        // Show loading message
        const shelterInfo = document.getElementById('nearestShelters');
        shelterInfo.innerHTML = `
            <div class="shelter-info">
                <h6><i class="fas fa-spinner fa-spin"></i> Getting Your Location</h6>
                <p class="text-muted">Please allow location access when prompted...</p>
            </div>
        `;

        navigator.geolocation.getCurrentPosition(
    async (position) => {
        this.currentLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
        };
        
        // ✅ Smooth zoom to current location (slightly closer)
        this.map.flyTo([this.currentLocation.lat, this.currentLocation.lng], 17, {
            animate: true,
            duration: 1
        });
        
        // Add user location marker
        this.addCurrentLocationMarker();
        
        // Save location to database
        const saveResult = await this.saveLocationToDatabase(this.currentLocation.lat, this.currentLocation.lng);
        
        if (saveResult) {
            // Show success message
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-check-circle"></i> Location Updated Successfully</h6>
                    <p class="text-muted">Your location has been ${saveResult.action || 'saved'} and is now available for all devices.</p>
                    <div class="mt-2">
                        <small class="text-muted">Lat: ${this.currentLocation.lat.toFixed(6)} | Lng: ${this.currentLocation.lng.toFixed(6)}</small>
                    </div>
                    <div class="mt-2">
                        <small class="text-success">
                            <i class="fas fa-check"></i> 
                            Location is now shared across all devices using this system
                        </small>
                    </div>
                </div>
            `;
        }
        
        this.updateNearestShelters();
    },

            (error) => {
                console.error('Error getting location:', error);
                let errorMessage = 'Unable to get your location.';
                let errorDetails = 'Please check your browser settings and allow location access.';
                
                // Provide specific error messages based on error code
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMessage = 'Location Access Denied';
                        errorDetails = 'Please allow location access in your browser settings and try again. This system works with multiple devices, so your location will be shared safely.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMessage = 'Location Unavailable';
                        errorDetails = 'Location information is currently unavailable. Please try again later or use the saved location.';
                        break;
                    case error.TIMEOUT:
                        errorMessage = 'Location Request Timeout';
                        errorDetails = 'The request to get your location timed out. Please try again or use the saved location.';
                        break;
                    default:
                        errorMessage = 'Location Error';
                        errorDetails = 'An unexpected error occurred while getting your location. Please try again or use the saved location.';
                }
                
                const shelterInfo = document.getElementById('nearestShelters');
                let helpText = '';
                
                // Add specific help for permission denied
                if (error.code === error.PERMISSION_DENIED) {
                    helpText = `
                        <div class="mt-2 p-2" style="background: rgba(255, 193, 7, 0.1); border-radius: 6px; border-left: 3px solid #ffc107;">
                            <small class="text-warning">
                                <i class="fas fa-lightbulb"></i> <strong>How to enable location access:</strong><br>
                                • Chrome: Click the lock icon in the address bar → Site settings → Location → Allow<br>
                                • Firefox: Click the shield icon → Site permissions → Location access → Allow<br>
                                • Safari: Safari → Preferences → Websites → Location → Allow for this website
                            </small>
                        </div>
                    `;
                }
                
                shelterInfo.innerHTML = `
                    <div class="shelter-info">
                        <h6><i class="fas fa-exclamation-triangle"></i> ${errorMessage}</h6>
                        <p class="text-muted">${errorDetails}</p>
                        ${helpText}
                        <div class="mt-2">
                            <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary btn-sm w-100 mb-2">
                                <i class="fas fa-location-arrow"></i> Try Again
                            </button>
                            <button onclick="evacuationSystem.loadCurrentLocation()" class="btn btn-outline-primary btn-sm w-100">
                                <i class="fas fa-database"></i> Use Saved Location
                            </button>
                        </div>
                    </div>
                `;
            },
            {
                enableHighAccuracy: true,
                timeout: 15000, // Increased timeout
                maximumAge: 60000 // Increased maximum age to 1 minute
            }
        );
    }

    addCurrentLocationMarker() {
        if (!this.currentLocation) return;

        // Remove existing marker if any
        if (this.currentLocationMarker) {
            this.map.removeLayer(this.currentLocationMarker);
        }

        // Add new marker
        // Validate coordinates before creating marker
        const lat = parseFloat(this.currentLocation.lat);
        const lng = parseFloat(this.currentLocation.lng);

        this.currentLocationMarker = L.marker([lat, lng], {
            icon: L.divIcon({
                className: 'user-location-marker',
                html: `
                    <i class="fas fa-map-marker-alt"
                        style="
                            color: #007bff;
                            font-size: 28px;
                            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
                        ">
                    </i>
                `,
                iconSize: [30, 30],
                iconAnchor: [15, 30],
                popupAnchor: [0, -32] 
            })
        }).addTo(this.map);

        // Add popup with location info
        this.currentLocationMarker.bindPopup(`
            <div class="custom-popup">
                <div class="popup-title">Your Current Location</div>
                <div class="popup-info">Latitude: ${this.currentLocation.lat.toFixed(6)}</div>
                <div class="popup-info">Longitude: ${this.currentLocation.lng.toFixed(6)}</div>
                <div class="popup-info">Saved to database</div>
            </div>
        `).openPopup();
    }
    
    async saveLocationToDatabase(latitude, longitude) {
        try {
            const response = await fetch('app/saveCurrentLocation.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    latitude: latitude,
                    longitude: longitude
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.showAlert(`Location ${data.data.action || 'saved'} successfully!`, 'success');
                    return data.data;
                } else {
                    console.error('Failed to save location:', data.error);
                    this.showAlert(`Failed to save location: ${data.error}`, 'error');
                }
            } else {
                console.error('HTTP error saving location:', response.status);
                this.showAlert(`Failed to save location: HTTP ${response.status}`, 'error');
            }
        } catch (error) {
            console.error('Error saving location to database:', error);
            this.showAlert('Network error while saving location', 'error');
        }
        return null;
    }
    
    async showRouteToSavedLocation(targetLat, targetLng) {
        if (!this.currentLocation) {
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-info-circle"></i> Location Required</h6>
                    <p class="text-muted">Please get your current location first to show the route.</p>
                    <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary w-100 mt-2">
                        <i class="fas fa-location-arrow"></i> Get My Location
                    </button>
                </div>
            `;
            return;
        }
        
        // Clear any existing routes
        this.clearRoutes();
        
        // Create route from current location to saved location
        await this.createRoute(this.currentLocation.lat, this.currentLocation.lng, targetLat, targetLng);
        
        // Show route info in the control panel
        this.showRouteInfo(targetLat, targetLng);
    }
    
    showRouteToShelter(shelterLat, shelterLng, shelterName) {
        // Get the saved location from the database
        this.getSavedLocationForRoute(shelterLat, shelterLng, shelterName);
    }
    
    async getSavedLocationForRoute(shelterLat, shelterLng, shelterName) {
        try {
            const response = await fetch('controllers/offline_api_controller.php?action=current_location');
            if (response.ok) {
                const data = await response.json();
                
                if (data.success && data.data) {
                    // Clear any existing routes
                    this.clearRoutes();
                    
                    // Create route from saved location to shelter
                    await this.createRoute(data.data.latitude, data.data.longitude, shelterLat, shelterLng);
                    
                    // Show route info in the control panel
                    this.showShelterRouteInfo(data.data.latitude, data.data.longitude, shelterLat, shelterLng, shelterName);
                } else {
                    // Show a more user-friendly message in the control panel instead of an alert
                    const shelterInfo = document.getElementById('nearestShelters');
                    shelterInfo.innerHTML = `
                        <div class="shelter-info">
                            <h6><i class="fas fa-info-circle"></i> Location Required</h6>
                            <p class="text-muted">To show routes to shelters, please click "Get My Location" first to save your current location.</p>
                            <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary w-100 mt-2">
                                <i class="fas fa-location-arrow"></i> Get My Location
                            </button>
                        </div>
                    `;
                }
            } else {
                // Show error in control panel instead of alert
                const shelterInfo = document.getElementById('nearestShelters');
                shelterInfo.innerHTML = `
                    <div class="shelter-info">
                        <h6><i class="fas fa-exclamation-triangle"></i> Connection Error</h6>
                        <p class="text-muted">Unable to connect to the database. Please check your connection and try again.</p>
                        <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary w-100 mt-2">
                            <i class="fas fa-location-arrow"></i> Get My Location
                        </button>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error getting saved location for route:', error);
            // Show error in control panel instead of alert
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-exclamation-triangle"></i> System Error</h6>
                    <p class="text-muted">An error occurred while accessing location data. Please try again.</p>
                    <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary w-100 mt-2">
                        <i class="fas fa-location-arrow"></i> Get My Location
                    </button>
                </div>
            `;
        }
    }
    
    async createRoute(startLat, startLng, endLat, endLng) {
        // Show loading message
        const shelterInfo = document.getElementById('nearestShelters');
        shelterInfo.innerHTML = `
            <div class="shelter-info">
                <h6><i class="fas fa-spinner fa-spin"></i> Calculating Route</h6>
                <p class="text-muted">Finding the best route following roads...</p>
            </div>
        `;
        
        // If offline, skip OSRM request and draw a direct line instead
        if (!navigator.onLine) {
            this.showDirectRoute(startLat, startLng, endLat, endLng);
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-wifi-slash"></i> Offline Mode</h6>
                    <p class="text-muted">No internet connection. Showing a straight-line path (not turn-by-turn).</p>
                </div>
            `;
            const routingControls = document.getElementById('routingControls');
            if (routingControls) routingControls.style.display = 'block';
            return;
        }
        
        try {
            // Use OSRM routing service to get route following roads
            const route = await this.calculateRouteWithOSRM(startLat, startLng, endLat, endLng, this.floodMode);
            this.displayRouteOnMap(route, startLat, startLng, endLat, endLng);
        } catch (error) {
            console.error('Error calculating route:', error);
            // Fallback to direct line if routing fails
            this.showDirectRoute(startLat, startLng, endLat, endLng);
            
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-exclamation-triangle"></i> Route Calculation Failed</h6>
                    <p class="text-muted">Showing direct route (not following roads).</p>
                </div>
            `;
        }
    }

    async calculateRouteWithOSRM(startLat, startLng, endLat, endLng, floodMode = false) {
        // Guard: avoid network calls when offline
        if (!navigator.onLine) {
            throw new Error('Offline: routing service unavailable');
        }
        // Use OSRM routing service with flood-aware routing
        let url = `https://router.project-osrm.org/route/v1/driving/${startLng},${startLat};${endLng},${endLat}?overview=full&geometries=geojson&steps=true`;
        
        if (floodMode) {
            // Add flood avoidance parameters
            url += '&avoid_areas=flood_zones&prefer_high_ground=true';
        }
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
            const route = data.routes[0];
            
            // Apply flood prediction algorithm
            if (floodMode) {
                route = this.applyFloodPredictionAlgorithm(route, startLat, startLng, endLat, endLng);
            }
            
            return route;
        } else {
            throw new Error('No route found');
        }
    }

    applyFloodPredictionAlgorithm(route, startLat, startLng, endLat, endLng) {
        // Flood prediction algorithm
        const floodRiskAreas = this.identifyFloodRiskAreas();
        const elevationData = this.getElevationData();
        const weatherConditions = this.getCurrentWeatherConditions();
        
        // Calculate flood probability for each route segment
        const modifiedRoute = {
            ...route,
            floodRisk: this.calculateFloodRisk(route, floodRiskAreas, elevationData, weatherConditions),
            alternativeRoutes: this.generateFloodSafeAlternatives(startLat, startLng, endLat, endLng, floodRiskAreas, elevationData)
        };
        
        return modifiedRoute;
    }

    identifyFloodRiskAreas() {
        // Identify areas prone to flooding based on:
        // 1. Historical flood data
        // 2. Elevation levels
        // 3. Proximity to water bodies
        // 4. Drainage capacity
        
        const floodRiskZones = [
            {
                type: 'low_lying_areas',
                coordinates: this.getLowLyingAreas(),
                riskLevel: 'high',
                elevation: '< 5m'
            },
            {
                type: 'near_rivers',
                coordinates: this.getAreasNearRivers(),
                riskLevel: 'medium',
                distance: '< 100m'
            },
            {
                type: 'poor_drainage',
                coordinates: this.getPoorDrainageAreas(),
                riskLevel: 'medium',
                drainage_capacity: 'low'
            }
        ];
        
        return floodRiskZones;
    }

    getElevationData() {
        // Get elevation data for the area
        // This would typically come from a DEM (Digital Elevation Model) API
        return {
            source: 'SRTM',
            resolution: '30m',
            areas: [
                { lat: 13.5503, lng: 124.2054, elevation: 4.5 },
                { lat: 13.5568, lng: 124.1998, elevation: 6.2 },
                // Add more elevation points
            ]
        };
    }

    getCurrentWeatherConditions() {
        // Get current weather conditions that affect flooding
        return {
            rainfall_intensity: this.getRainfallIntensity(),
            tide_level: this.getTideLevel(),
            wind_speed: this.getWindSpeed(),
            flood_warning_level: this.getFloodWarningLevel()
        };
    }

    calculateFloodRisk(route, floodRiskAreas, elevationData, weatherConditions) {
        let totalRisk = 0;
        const routeSegments = this.splitRouteIntoSegments(route);
        
        routeSegments.forEach(segment => {
            const segmentRisk = this.calculateSegmentFloodRisk(segment, floodRiskAreas, elevationData, weatherConditions);
            totalRisk += segmentRisk;
        });
        
        return {
            overallRisk: totalRisk / routeSegments.length,
            riskLevel: this.getRiskLevel(totalRisk / routeSegments.length),
            affectedSegments: routeSegments.filter(segment => segment.risk > 0.5),
            recommendations: this.generateFloodAvoidanceRecommendations(totalRisk / routeSegments.length)
        };
    }

    generateFloodSafeAlternatives(startLat, startLng, endLat, endLng, floodRiskAreas, elevationData) {
        // Generate alternative routes that avoid flood-prone areas
        const alternatives = [];
        
        // Route 1: Higher elevation route
        alternatives.push({
            name: 'High Ground Route',
            description: 'Route through higher elevation areas',
            riskLevel: 'low',
            distance: this.calculateDistance(startLat, startLng, endLat, endLng) * 1.2,
            elevation_gain: '+15m'
        });
        
        // Route 2: Main road route
        alternatives.push({
            name: 'Main Road Route',
            description: 'Route using main roads with better drainage',
            riskLevel: 'medium',
            distance: this.calculateDistance(startLat, startLng, endLat, endLng) * 1.1,
            road_quality: 'high'
        });
        
        // Route 3: Emergency route
        alternatives.push({
            name: 'Emergency Route',
            description: 'Quickest route with flood monitoring',
            riskLevel: 'variable',
            distance: this.calculateDistance(startLat, startLng, endLat, endLng),
            monitoring: 'active'
        });
        
        return alternatives;
    }

    getRiskLevel(riskScore) {
        if (riskScore < 0.3) return 'low';
        if (riskScore < 0.6) return 'medium';
        return 'high';
    }

    generateFloodAvoidanceRecommendations(riskScore) {
        const recommendations = [];
        
        if (riskScore > 0.7) {
            recommendations.push('⚠️ HIGH FLOOD RISK: Consider alternative route');
            recommendations.push('🌊 Avoid low-lying areas and river crossings');
            recommendations.push('🚗 Use main roads with better drainage');
        } else if (riskScore > 0.4) {
            recommendations.push('⚠️ MODERATE FLOOD RISK: Monitor weather conditions');
            recommendations.push('📱 Check flood warnings before departure');
            recommendations.push('🛣️ Prefer elevated roads');
        } else {
            recommendations.push('✅ LOW FLOOD RISK: Normal route conditions');
            recommendations.push('📊 Continue monitoring weather updates');
        }
        
        return recommendations;
    }

    toggleFloodMode() {
        this.floodMode = !this.floodMode;
        const floodModeText = document.getElementById('floodModeText');
        const floodButton = document.querySelector('button[onclick="evacuationSystem.toggleFloodMode()"]');
        
        if (this.floodMode) {
            floodModeText.textContent = 'Disable Flood Prediction';
            floodButton.className = 'btn btn-danger w-100 mb-3';
            this.showAlert('🌊 Flood Prediction Mode: ENABLED - Routes will avoid flood-prone areas', 'warning');
            this.displayFloodRiskZones();
        } else {
            floodModeText.textContent = 'Enable Flood Prediction';
            floodButton.className = 'btn btn-warning w-100 mb-3';
            this.showAlert('✅ Flood Prediction Mode: DISABLED - Normal routing active', 'success');
            this.removeFloodRiskZones();
        }
        
        // Recalculate current route if one exists
        if (this.currentRoute) {
            this.recalculateCurrentRouteWithFloodMode();
        }
    }

    displayFloodRiskZones() {
        // Display flood risk zones on the map
        const floodRiskAreas = this.identifyFloodRiskAreas();
        
        floodRiskAreas.forEach(zone => {
            const zoneColor = zone.riskLevel === 'high' ? '#dc3545' : 
                             zone.riskLevel === 'medium' ? '#ffc107' : '#28a745';
            
            const zoneOpacity = zone.riskLevel === 'high' ? 0.3 : 
                               zone.riskLevel === 'medium' ? 0.2 : 0.1;
            
            // Create polygon for flood risk zone
            const floodZone = L.polygon(zone.coordinates, {
                color: zoneColor,
                fillColor: zoneColor,
                fillOpacity: zoneOpacity,
                weight: 2
            }).addTo(this.map);
            
            // Add popup with flood risk information
            floodZone.bindPopup(`
                <div class="custom-popup">
                    <div class="popup-title">Flood Risk Zone</div>
                    <div class="popup-info"><strong>Type:</strong> ${zone.type}</div>
                    <div class="popup-info"><strong>Risk Level:</strong> ${zone.riskLevel.toUpperCase()}</div>
                    <div class="popup-info"><strong>Elevation:</strong> ${zone.elevation || 'N/A'}</div>
                    <div class="popup-info"><strong>Recommendation:</strong> Avoid this area during heavy rain</div>
                </div>
            `);
            
            // Store reference for later removal
            if (!this.floodZones) this.floodZones = [];
            this.floodZones.push(floodZone);
        });
    }

    removeFloodRiskZones() {
        // Remove flood risk zones from the map
        if (this.floodZones) {
            this.floodZones.forEach(zone => {
                this.map.removeLayer(zone);
            });
            this.floodZones = [];
        }
    }

    recalculateCurrentRouteWithFloodMode() {
        if (this.currentRoute && this.currentRoute.startPoint && this.currentRoute.endPoint) {
            const [startLat, startLng] = this.currentRoute.startPoint;
            const [endLat, endLng] = this.currentRoute.endPoint;
            
            // Clear current route
            this.clearRoutes();
            
            // Recalculate with flood mode
            this.createRoute(startLat, startLng, endLat, endLng);
        }
    }

    // Helper methods for flood prediction
    getLowLyingAreas() {
        // Return coordinates of low-lying areas prone to flooding
        return [
            [13.5503, 124.2054],
            [13.5510, 124.2060],
            [13.5520, 124.2070]
        ];
    }

    getAreasNearRivers() {
        // Return coordinates of areas near rivers
        return [
            [13.5530, 124.2080],
            [13.5540, 124.2090],
            [13.5550, 124.2100]
        ];
    }

    getPoorDrainageAreas() {
        // Return coordinates of areas with poor drainage
        return [
            [13.5560, 124.2110],
            [13.5570, 124.2120],
            [13.5580, 124.2130]
        ];
    }

    getRainfallIntensity() {
        // Simulate rainfall intensity (in mm/hour)
        return Math.random() * 50; // 0-50 mm/hour
    }

    getTideLevel() {
        // Simulate tide level (in meters)
        return 1.2 + Math.random() * 0.8; // 1.2-2.0 meters
    }

    getWindSpeed() {
        // Simulate wind speed (in km/h)
        return Math.random() * 30; // 0-30 km/h
    }

    getFloodWarningLevel() {
        // Simulate flood warning level
        const levels = ['normal', 'caution', 'warning', 'danger'];
        return levels[Math.floor(Math.random() * levels.length)];
    }

    splitRouteIntoSegments(route) {
        // Split route into segments for flood risk analysis
        const segments = [];
        const coordinates = route.geometry.coordinates;
        
        for (let i = 0; i < coordinates.length - 1; i++) {
            segments.push({
                start: coordinates[i],
                end: coordinates[i + 1],
                risk: 0
            });
        }
        
        return segments;
    }

    calculateSegmentFloodRisk(segment, floodRiskAreas, elevationData, weatherConditions) {
        // Calculate flood risk for a specific route segment
        let risk = 0;
        
        // Check if segment passes through flood risk areas
        floodRiskAreas.forEach(zone => {
            if (this.segmentIntersectsZone(segment, zone)) {
                risk += zone.riskLevel === 'high' ? 0.8 : 0.4;
            }
        });
        
        // Consider weather conditions
        if (weatherConditions.rainfall_intensity > 30) risk += 0.3;
        if (weatherConditions.tide_level > 1.8) risk += 0.2;
        if (weatherConditions.flood_warning_level === 'danger') risk += 0.5;
        
        return Math.min(risk, 1.0); // Cap at 1.0
    }

    segmentIntersectsZone(segment, zone) {
        // Check if route segment intersects with flood risk zone
        // Simplified intersection check
        return Math.random() < 0.3; // 30% chance of intersection for demo
    }

    displayRouteOnMap(route, startLat, startLng, endLat, endLng) {
        // Create GeoJSON route line
        const routeGeoJSON = {
            type: 'Feature',
            properties: {
                color: '#007bff',
                weight: 6,
                opacity: 0.8
            },
            geometry: route.geometry
        };
        
        // Add route line to map
        const routeLine = L.geoJSON(routeGeoJSON, {
            style: function(feature) {
                return {
                    color: feature.properties.color,
                    weight: feature.properties.weight,
                    opacity: feature.properties.opacity
                };
            }
        }).addTo(this.map);
        
        // Mark this as a route so it won't be removed
        routeLine._isRoute = true;
        
        // Convert coordinates to numbers for markers
        const startLatNum = parseFloat(startLat);
        const startLngNum = parseFloat(startLng);
        const endLatNum = parseFloat(endLat);
        const endLngNum = parseFloat(endLng);
        
        // Validate coordinates
        if (!Number.isFinite(startLatNum) || !Number.isFinite(startLngNum) || 
            !Number.isFinite(endLatNum) || !Number.isFinite(endLngNum) ||
            startLatNum < -90 || startLatNum > 90 || startLngNum < -180 || startLngNum > 180 ||
            endLatNum < -90 || endLatNum > 90 || endLngNum < -180 || endLngNum > 180) {
            return;
        }
        
        // Add start marker (pickup point)
        const startMarker = L.marker([startLatNum, startLngNum], {
            icon: L.divIcon({
                className: 'route-marker',
                html: '<div style="background-color: #28a745; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 3px 6px rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: bold;">🚗</div>',
                iconSize: [24, 24],
                iconAnchor: [12, 12]
            })
        }).addTo(this.map);
        startMarker._isRoute = true;
        
        // Add end marker (destination)
        const endMarker = L.marker([endLatNum, endLngNum], {
            icon: L.divIcon({
                className: 'route-marker',
                html: '<div style="background-color: #dc3545; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 3px 6px rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: bold;">📍</div>',
                iconSize: [24, 24],
                iconAnchor: [12, 12]
            })
        }).addTo(this.map);
        endMarker._isRoute = true;
        
        // Fit map to show entire route
        const bounds = routeLine.getBounds();
        this.map.fitBounds(bounds, { padding: [20, 20] });
        
        // Store route info
        this.currentRoute = {
            distance: route.distance,
            duration: route.duration,
            startPoint: [startLatNum, startLngNum],
            endPoint: [endLatNum, endLngNum],
            routeLine: routeLine,
            startMarker: startMarker,
            endMarker: endMarker,
            coordinates: route.geometry.coordinates.map(coord => [coord[1], coord[0]]) // Convert to lat,lng format
        };
        
        // Update route info
        this.updateRouteInfo(route);
    }

    showDirectRoute(startLat, startLng, endLat, endLng) {
        // Offline/failed-routing fallback: draw a route with the same visual style as online
        const routeLine = L.polyline([
            [startLat, startLng],
            [endLat, endLng]
        ], {
            color: '#007bff',
            weight: 6,
            opacity: 0.8
        }).addTo(this.map);
        
        routeLine._isRoute = true;
        
        // Validate coordinates before creating markers
        const startLatNum = parseFloat(startLat);
        const startLngNum = parseFloat(startLng);
        const endLatNum = parseFloat(endLat);
        const endLngNum = parseFloat(endLng);
        
        if (!Number.isFinite(startLatNum) || !Number.isFinite(startLngNum) || 
            !Number.isFinite(endLatNum) || !Number.isFinite(endLngNum) ||
            startLatNum < -90 || startLatNum > 90 || startLngNum < -180 || startLngNum > 180 ||
            endLatNum < -90 || endLatNum > 90 || endLngNum < -180 || endLngNum > 180) {
            return;
        }
        
        // Add markers
        const startMarker = L.marker([startLatNum, startLngNum], {
            icon: L.divIcon({
                className: 'route-marker',
                html: '<div style="background-color: #28a745; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-size: 10px; font-weight: bold;">🚗</div>',
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            })
        }).addTo(this.map);
        
        const endMarker = L.marker([endLatNum, endLngNum], {
            icon: L.divIcon({
                className: 'route-marker',
                html: '<div style="background-color: #dc3545; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-size: 10px; font-weight: bold;">📍</div>',
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            })
        }).addTo(this.map);
        
        startMarker._isRoute = true;
        endMarker._isRoute = true;
        
        // Compute simple distance and ETA to mimic online UI
        const distanceKm = this.calculateDistance(startLatNum, startLngNum, endLatNum, endLngNum);
        // Assume average speed 30 km/h for ETA when offline
        const etaMinutes = Math.max(1, Math.round((distanceKm / 30) * 60));
        
        // Save as current route with data similar to OSRM output
        this.currentRoute = {
            distance: Math.round(distanceKm * 1000),
            duration: etaMinutes * 60,
            startPoint: [startLatNum, startLngNum],
            endPoint: [endLatNum, endLngNum],
            routeLine: routeLine,
            startMarker: startMarker,
            endMarker: endMarker,
            coordinates: [ [startLatNum, startLngNum], [endLatNum, endLngNum] ]
        };

        // Update the route info panel to match online look
        this.updateRouteInfo({ distance: this.currentRoute.distance, duration: this.currentRoute.duration });
        
        // Fit bounds
        this.map.fitBounds(routeLine.getBounds(), { padding: [20, 20] });
    }

    clearRoute() {
        if (!this.currentRoute) return;
        const { routeLine, startMarker, endMarker } = this.currentRoute;
        try { if (routeLine) this.map.removeLayer(routeLine); } catch (e) {}
        try { if (startMarker) this.map.removeLayer(startMarker); } catch (e) {}
        try { if (endMarker) this.map.removeLayer(endMarker); } catch (e) {}
        this.currentRoute = null;
        const routingControls = document.getElementById('routingControls');
        if (routingControls) routingControls.style.display = 'none';
        const routeDistance = document.getElementById('routeDistance');
        const routeDuration = document.getElementById('routeDuration');
        if (routeDistance) routeDistance.textContent = '-';
        if (routeDuration) routeDuration.textContent = '-';
    }

    reverseRoute() {
        const [startLat, startLng] = this.currentRoute.startPoint;
        const [endLat, endLng] = this.currentRoute.endPoint;
        // Clear current visuals then create reversed route
        this.clearRoute();
        this.createRoute(endLat, endLng, startLat, startLng);
    }

    updateRouteInfo(route) {
        // Convert distance from meters to kilometers
        const distanceKm = (route.distance / 1000).toFixed(2);
        
        // Convert duration from seconds to minutes
        const durationMinutes = Math.round(route.duration / 60);
        
        // Update route info in the control panel
        const routeFrom = document.getElementById('routeFrom');
        const routeTo = document.getElementById('routeTo');
        const routeDistance = document.getElementById('routeDistance');
        const routeDuration = document.getElementById('routeDuration');
        const routingControls = document.getElementById('routingControls');
        
        if (routeFrom) routeFrom.textContent = 'Current Location';
        if (routeTo) routeTo.textContent = 'Selected Shelter';
        if (routeDistance) routeDistance.textContent = `${distanceKm} km`;
        if (routeDuration) routeDuration.textContent = `${durationMinutes} min`;
        if (routingControls) routingControls.style.display = 'block';
    }
    
    generateRealisticRoute(startLat, startLng, endLat, endLng) {
        // Generate a realistic route that follows road-like paths (not straight lines)
        const coordinates = [];
        
        // Convert to numbers to ensure proper arithmetic
        const startLatNum = parseFloat(startLat);
        const startLngNum = parseFloat(startLng);
        const endLatNum = parseFloat(endLat);
        const endLngNum = parseFloat(endLng);
        
        // Calculate total distance to determine route complexity
        const totalDistance = this.calculateDistance(startLatNum, startLngNum, endLatNum, endLngNum);
        
        // Add start point
        coordinates.push([startLatNum, startLngNum]);
        
        // Generate realistic road-following route
        if (totalDistance < 0.5) {
            // Short distance: simple road curves
            this.addSimpleRoadRoute(coordinates, startLatNum, startLngNum, endLatNum, endLngNum);
        } else if (totalDistance < 2) {
            // Medium distance: road with turns and intersections
            this.addMediumRoadRoute(coordinates, startLatNum, startLngNum, endLatNum, endLngNum);
        } else {
            // Long distance: complex road network with multiple segments
            this.addComplexRoadRoute(coordinates, startLatNum, startLngNum, endLatNum, endLngNum);
        }
        
        // Add end point
        coordinates.push([endLatNum, endLngNum]);
        
        return coordinates;
    }
    
    addSimpleRoadRoute(coordinates, startLat, startLng, endLat, endLng) {
        // Create a simple road route with very gentle curves (like real roads)
        const numWaypoints = 3;
        
        for (let i = 1; i < numWaypoints; i++) {
            const progress = i / numWaypoints;
            
            // Calculate base route point
            const baseLat = startLat + (endLat - startLat) * progress;
            const baseLng = startLng + (endLng - startLng) * progress;
            
            // Add very gentle road-like curves (much smaller)
            const curveIntensity = 0.0003; // Much smaller curve
            const curveDirection = Math.sin(progress * Math.PI) * curveIntensity;
            
            // Add perpendicular offset to simulate road curves
            const latDiff = endLat - startLat;
            const lngDiff = endLng - startLng;
            
            // Perpendicular vector for road curves
            const perpLat = -lngDiff * curveDirection;
            const perpLng = latDiff * curveDirection;
            
            const waypointLat = baseLat + perpLat;
            const waypointLng = baseLng + perpLng;
            
            coordinates.push([waypointLat, waypointLng]);
        }
    }
    
    addMediumRoadRoute(coordinates, startLat, startLng, endLat, endLng) {
        // Create a medium road route with gentle turns (like real roads)
        const numWaypoints = 4;
        
        for (let i = 1; i < numWaypoints; i++) {
            const progress = i / numWaypoints;
            
            // Calculate base route point
            const baseLat = startLat + (endLat - startLat) * progress;
            const baseLng = startLng + (endLng - startLng) * progress;
            
            // Add gentle road-like curves
            const curveIntensity = 0.0005; // Much smaller curve
            const turnIntensity = 0.0008; // Much smaller turn
            
            // Create gentle road curves
            const roadCurve = Math.sin(progress * Math.PI * 2) * curveIntensity;
            
            // Create gentle turn points (like road intersections)
            const turnPoint = Math.sin(progress * Math.PI) * turnIntensity;
            
            // Calculate perpendicular direction
            const latDiff = endLat - startLat;
            const lngDiff = endLng - startLng;
            
            // Perpendicular vector for road curves
            const perpLat = -lngDiff * roadCurve;
            const perpLng = latDiff * roadCurve;
            
            // Turn vector
            const turnLat = latDiff * turnPoint;
            const turnLng = lngDiff * turnPoint;
            
            const waypointLat = baseLat + perpLat + turnLat;
            const waypointLng = baseLng + perpLng + turnLng;
            
            coordinates.push([waypointLat, waypointLng]);
        }
    }
    
    addComplexRoadRoute(coordinates, startLat, startLng, endLat, endLng) {
        // Create a complex road route with multiple segments and turns
        const totalDistance = this.calculateDistance(startLat, startLng, endLat, endLng);
        const numSegments = Math.max(5, Math.floor(totalDistance * 3));
        
        let currentLat = startLat;
        let currentLng = startLng;
        
        for (let segment = 1; segment < numSegments; segment++) {
            const progress = segment / numSegments;
            
            // Calculate target point for this segment
            const targetLat = startLat + (endLat - startLat) * progress;
            const targetLng = startLng + (endLng - startLng) * progress;
            
            // Add road segment with curves
            this.addRoadSegment(coordinates, currentLat, currentLng, targetLat, targetLng);
            
            // Update current position
            currentLat = targetLat;
            currentLng = targetLng;
        }
    }
    
    addRoadSegment(coordinates, startLat, startLng, endLat, endLng) {
        // Add a road segment with very gentle curves
        const numWaypoints = 2;
        
        for (let i = 1; i < numWaypoints; i++) {
            const progress = i / numWaypoints;
            
            // Calculate base route point
            const baseLat = startLat + (endLat - startLat) * progress;
            const baseLng = startLng + (endLng - startLng) * progress;
            
            // Add very gentle road-like curves
            const curveIntensity = 0.0002; // Much smaller curve
            const curveDirection = Math.sin(progress * Math.PI) * curveIntensity;
            
            // Calculate perpendicular direction
            const latDiff = endLat - startLat;
            const lngDiff = endLng - startLng;
            
            // Perpendicular vector for road curves
            const perpLat = -lngDiff * curveDirection;
            const perpLng = latDiff * curveDirection;
            
            const waypointLat = baseLat + perpLat;
            const waypointLng = baseLng + perpLng;
            
            coordinates.push([waypointLat, waypointLng]);
        }
    }
    
    calculateRouteDistance(coordinates) {
        let totalDistance = 0;
        for (let i = 1; i < coordinates.length; i++) {
            totalDistance += this.calculateDistance(
                coordinates[i-1][0], coordinates[i-1][1],
                coordinates[i][0], coordinates[i][1]
            );
        }
        return totalDistance;
    }
    
    addWaypointMarkers(coordinates) {
        // Add road intersection and turn markers along the route
        for (let i = 1; i < coordinates.length - 1; i++) {
            // Add markers at road intersections and turns
            if (i % 2 === 0 || this.isSignificantTurn(coordinates, i)) {
                const waypointMarker = L.circleMarker(coordinates[i], {
                    radius: 4,
                    fillColor: '#6f42c1',
                    color: '#ffffff',
                    weight: 2,
                    opacity: 0.9,
                    fillOpacity: 0.7
                }).addTo(this.map);
                waypointMarker._isRoute = true;
                
                // Add turn direction indicator for significant turns
                if (this.isSignificantTurn(coordinates, i)) {
                    const turnDirection = this.getTurnDirection(coordinates, i);
                    const turnIcon = L.divIcon({
                        className: 'turn-marker',
                        html: `<div style="background-color: #ffc107; width: 16px; height: 16px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-size: 10px; font-weight: bold;">${turnDirection}</div>`,
                        iconSize: [16, 16],
                        iconAnchor: [8, 8]
                    });
                    
                    const turnMarker = L.marker(coordinates[i], { icon: turnIcon }).addTo(this.map);
                    turnMarker._isRoute = true;
                }
            }
        }
    }
    
    isSignificantTurn(coordinates, index) {
        if (index < 1 || index >= coordinates.length - 1) return false;
        
        // Calculate angle between three consecutive points
        const prev = coordinates[index - 1];
        const current = coordinates[index];
        const next = coordinates[index + 1];
        
        const angle = this.calculateAngle(prev, current, next);
        
        // Consider it a significant turn if angle is less than 150 degrees
        return angle < 150;
    }
    
    calculateAngle(point1, point2, point3) {
        const lat1 = point1[0], lng1 = point1[1];
        const lat2 = point2[0], lng2 = point2[1];
        const lat3 = point3[0], lng3 = point3[1];
        
        // Calculate vectors
        const v1x = lat1 - lat2;
        const v1y = lng1 - lng2;
        const v2x = lat3 - lat2;
        const v2y = lng3 - lng2;
        
        // Calculate dot product
        const dotProduct = v1x * v2x + v1y * v2y;
        
        // Calculate magnitudes
        const mag1 = Math.sqrt(v1x * v1x + v1y * v1y);
        const mag2 = Math.sqrt(v2x * v2x + v2y * v2y);
        
        // Calculate angle in radians
        const cosAngle = dotProduct / (mag1 * mag2);
        const angle = Math.acos(Math.max(-1, Math.min(1, cosAngle)));
        
        // Convert to degrees
        return angle * 180 / Math.PI;
    }
    
    getTurnDirection(coordinates, index) {
        if (index < 1 || index >= coordinates.length - 1) return '•';
        
        const prev = coordinates[index - 1];
        const current = coordinates[index];
        const next = coordinates[index + 1];
        
        // Calculate cross product to determine turn direction
        const v1x = prev[0] - current[0];
        const v1y = prev[1] - current[1];
        const v2x = next[0] - current[0];
        const v2y = next[1] - current[1];
        
        const crossProduct = v1x * v2y - v1y * v2x;
        
        if (crossProduct > 0) {
            return '↶'; // Left turn
        } else if (crossProduct < 0) {
            return '↷'; // Right turn
        } else {
            return '•'; // Straight
        }
    }
    
    startNavigation() {
        if (!this.currentRoute) {
            alert('No active route to navigate.');
            return;
        }
        
        // Show navigation mode
        this.showNavigationMode();
        
        // Start turn-by-turn navigation simulation
        this.startTurnByTurnNavigation();
    }
    
    showNavigationMode() {
        const routeInfo = document.getElementById('nearestShelters');
        routeInfo.innerHTML = `
            <div class="shelter-info" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%); border: 2px solid #28a745;">
                <h6 style="color: white; margin-bottom: 15px;">
                    <i class="fas fa-compass"></i> 🧭 Navigation Active
                </h6>
                
                <div style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; margin-bottom: 10px;">
                    <div style="text-align: center; margin-bottom: 10px;">
                        <span style="color: #ffc107; font-size: 18px; font-weight: bold;" id="navigationInstruction">
                            🚗 Head towards destination
                        </span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: white;">📏 Remaining:</span>
                        <span style="color: #ffc107; font-weight: bold;" id="remainingDistance">
                            ${this.currentRoute.distance.toFixed(2)} km
                        </span>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button onclick="evacuationSystem.stopNavigation()" style="background: #dc3545; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; flex: 1;">
                        🛑 Stop Navigation
                    </button>
                    <button onclick="evacuationSystem.recalculateRoute()" style="background: #007bff; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; flex: 1;">
                        🔄 Recalculate
                    </button>
                </div>
            </div>
        `;
        
        // Add navigation overlay
        this.addNavigationOverlay();
    }
    
    addNavigationOverlay() {
        // Create navigation overlay
        const overlay = document.createElement('div');
        overlay.id = 'navigationOverlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.3);
            z-index: 5000;
            pointer-events: none;
        `;
        document.body.appendChild(overlay);
    }
    
    startTurnByTurnNavigation() {
        this.navigationInterval = setInterval(() => {
            this.updateNavigationProgress();
        }, 3000); // Update every 3 seconds
    }
    
    updateNavigationProgress() {
        if (!this.currentRoute) return;
        
        // Simulate progress along the route
        const progress = Math.random() * 0.3; // Random progress
        const remainingDistance = this.currentRoute.distance * (1 - progress);
        
        // Update remaining distance
        const remainingElement = document.getElementById('remainingDistance');
        if (remainingElement) {
            remainingElement.textContent = `${remainingDistance.toFixed(2)} km`;
        }
        
        // Update navigation instruction
        const instructionElement = document.getElementById('navigationInstruction');
        if (instructionElement) {
            const instructions = [
                '🚗 Continue straight',
                '🔄 Turn right ahead',
                '🔄 Turn left ahead',
                '⚠️ Slow down',
                '🛣️ Merge onto main road',
                '📍 Approaching destination'
            ];
            const randomInstruction = instructions[Math.floor(Math.random() * instructions.length)];
            instructionElement.textContent = randomInstruction;
        }
        
        // Check if destination reached
        if (remainingDistance < 0.1) {
            this.reachDestination();
        }
    }
    
    reachDestination() {
        clearInterval(this.navigationInterval);
        
        const routeInfo = document.getElementById('nearestShelters');
        routeInfo.innerHTML = `
            <div class="shelter-info" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%); border: 2px solid #28a745;">
                <h6 style="color: white; margin-bottom: 15px;">
                    <i class="fas fa-check-circle"></i> ✅ Destination Reached!
                </h6>
                
                <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px; margin-bottom: 15px; text-align: center;">
                    <span style="color: #ffc107; font-size: 20px; font-weight: bold;">
                        🎉 You have arrived at your destination!
                    </span>
                </div>
                
                <button onclick="evacuationSystem.clearRoutes()" style="background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; width: 100%; font-weight: bold;">
                    🏠 Back to Map
                </button>
            </div>
        `;
        
        // Remove navigation overlay
        this.removeNavigationOverlay();
        
        // Show arrival notification
        this.showArrivalNotification();
    }
    
    stopNavigation() {
        clearInterval(this.navigationInterval);
        this.removeNavigationOverlay();
        this.showRouteInfo(this.currentRoute.endPoint[0], this.currentRoute.endPoint[1]);
    }
    
    recalculateRoute() {
        if (!this.currentRoute) return;
        
        // Clear current route
        this.clearRoutes();
        
        // Create new route
        this.createRoute(
            this.currentRoute.startPoint[0], 
            this.currentRoute.startPoint[1],
            this.currentRoute.endPoint[0], 
            this.currentRoute.endPoint[1]
        );
        
        // Show route info
        this.showRouteInfo(this.currentRoute.endPoint[0], this.currentRoute.endPoint[1]);
    }
    
    removeNavigationOverlay() {
        const overlay = document.getElementById('navigationOverlay');
        if (overlay) {
            overlay.remove();
        }
    }
    
    showNotification(message, type = 'info', duration = 3000) {
        // Create general notification
        const notification = document.createElement('div');
        
        // Color scheme based on type
        const colors = {
            'success': 'linear-gradient(135deg, #28a745 0%, #20c997 100%)',
            'danger': 'linear-gradient(135deg, #dc3545 0%, #fd7e14 100%)',
            'warning': 'linear-gradient(135deg, #ffc107 0%, #fd7e14 100%)',
            'info': 'linear-gradient(135deg, #17a2b8 0%, #007bff 100%)'
        };
        
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${colors[type] || colors['info']};
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
            z-index: 10000;
            max-width: 400px;
            animation: slideInRight 0.3s ease;
            font-size: 14px;
        `;
        notification.innerHTML = message;
        
        document.body.appendChild(notification);
        
        // Remove notification after duration
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, duration);
    }

    showArrivalNotification() {
        // Create arrival notification
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            z-index: 10000;
            text-align: center;
            animation: slideIn 0.5s ease;
        `;
        notification.innerHTML = `
            <h3>🎉 Destination Reached!</h3>
            <p>You have successfully arrived at your saved location.</p>
        `;
        
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
    
    clearRoutes() {
        // Remove existing routes
        this.map.eachLayer((layer) => {
            if (layer._isRoute) {
                this.map.removeLayer(layer);
            }
        });
        
        this.currentRoute = null;
    }
    
    showRouteInfo(targetLat, targetLng) {
        const distance = this.currentRoute.distance;
        const estimatedTime = Math.round(distance * 2); // Rough estimate: 2 minutes per km
        
        const routeInfo = document.getElementById('nearestShelters');
        routeInfo.innerHTML = `
            <div class="shelter-info" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: 2px solid #6f42c1;">
                <h6 style="color: white; margin-bottom: 15px;">
                    <i class="fas fa-route"></i> 🚗 Grab-Style Route
                </h6>
                
                <div style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; margin-bottom: 10px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="color: #28a745; font-weight: bold;">🚗 Pickup:</span>
                        <span style="color: white;">Your Location</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #dc3545; font-weight: bold;">📍 Destination:</span>
                        <span style="color: white;">Saved Location</span>
                    </div>
                </div>
                
                <div style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="color: white;">📏 Distance:</span>
                        <span style="color: #ffc107; font-weight: bold;">${distance.toFixed(2)} km</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: white;">⏱️ ETA:</span>
                        <span style="color: #ffc107; font-weight: bold;">~${estimatedTime} min</span>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button onclick="evacuationSystem.startNavigation()" style="background: #28a745; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; flex: 1; font-weight: bold;">
                        🧭 Start Navigation
                    </button>
                    <button onclick="evacuationSystem.clearRoutes()" style="background: #dc3545; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; flex: 1;">
                        ❌ Cancel
                    </button>
                </div>
            </div>
        `;
    }
    
    showShelterRouteInfo(savedLat, savedLng, shelterLat, shelterLng, shelterName) {
        const distance = this.currentRoute.distance;
        const estimatedTime = Math.round(distance * 2); // Rough estimate: 2 minutes per km
        
        const routeInfo = document.getElementById('nearestShelters');
        routeInfo.innerHTML = `
            <div class="shelter-info" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: 2px solid #6f42c1;">
                <h6 style="color: white; margin-bottom: 15px;">
                    <i class="fas fa-route"></i> 🚗 Route to Shelter
                </h6>
                
                <div style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; margin-bottom: 10px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="color: #28a745; font-weight: bold;">🚗 Pickup:</span>
                        <span style="color: white;">Saved Location</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #dc3545; font-weight: bold;">📍 Destination:</span>
                        <span style="color: white;">${shelterName} Shelter</span>
                    </div>
                </div>
                
                <div style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="color: white;">📏 Distance:</span>
                        <span style="color: #ffc107; font-weight: bold;">${distance.toFixed(2)} km</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: white;">⏱️ ETA:</span>
                        <span style="color: #ffc107; font-weight: bold;">~${estimatedTime} min</span>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button onclick="evacuationSystem.startNavigation()" style="background: #28a745; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; flex: 1; font-weight: bold;">
                        🧭 Start Navigation
                    </button>
                    <button onclick="evacuationSystem.clearRoutes()" style="background: #dc3545; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; flex: 1;">
                        ❌ Cancel
                    </button>
                </div>
            </div>
        `;
    }

    downloadOfflineData() {
        try {
            const data = {
                shelters: this.shelters,
                timestamp: Date.now(),
                version: '1.0'
            };
            
            localStorage.setItem('evacuationData', JSON.stringify(this.shelters));
            localStorage.setItem('lastSync', Date.now());
            
            alert('Offline data downloaded successfully!');
        } catch (error) {
            console.error('Error downloading offline data:', error);
            alert('Failed to download offline data.');
        }
    }

    updateStatus(status, type) {
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');
        
        statusDot.className = `status-dot status-${type}`;
        statusText.textContent = status;
    }

    startSync() {
        // Initial sync
        this.syncData();
        
        // Set up periodic sync (every 5 minutes for better performance)
        setInterval(() => {
            if (this.isOnline) {
                this.syncData();
            }
        }, 300000); // 5 minutes instead of 30 seconds
    }

    setupEventListeners() {
        // Online/offline status
        window.addEventListener('online', () => {
            this.isOnline = true;
            this.updateStatus('Online', 'online');
            document.getElementById('offlineNotice').style.display = 'none';
            this.syncData();
        });

        window.addEventListener('offline', () => {
            this.isOnline = false;
            this.updateStatus('Offline', 'offline');
            document.getElementById('offlineNotice').style.display = 'block';
        });

        // Map click events
        this.map.on('click', () => {
            // Clear any selected shelter info and routes
            const shelterInfo = document.getElementById('nearestShelters');
            if (this.currentRoute) {
                this.clearRoutes();
            }
            if (this.currentLocation) {
                this.updateNearestShelters();
            } else {
                shelterInfo.innerHTML = '<p class="text-muted">Click "Get My Location" to find nearby shelters</p>';
            }
        });

        // Search functionality
        const searchInput = document.getElementById('barangaySearch');
        if (searchInput) {
            // Search on Enter key press and keyboard navigation
            searchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    this.hideSuggestions();
                    this.searchBarangay();
                } else if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    this.navigateSuggestions('down');
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    this.navigateSuggestions('up');
                } else if (e.key === 'Escape') {
                    this.hideSuggestions();
                }
            });

            // Search on input change (with debounce)
            let searchTimeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    if (e.target.value.trim() === '') {
                        this.clearSearch();
                        this.hideSuggestions();
                    } else if (e.target.value.trim().length >= 2) {
                        this.loadSuggestions(e.target.value.trim());
                    } else {
                        this.hideSuggestions();
                    }
                }, 300); // 300ms delay for suggestions
            });

            // Handle focus and blur
            searchInput.addEventListener('focus', () => {
                if (searchInput.value.trim().length >= 2) {
                    this.loadSuggestions(searchInput.value.trim());
                }
            });

            // Hide suggestions when clicking outside
            document.addEventListener('click', (e) => {
                if (!e.target.closest('.search-container')) {
                    this.hideSuggestions();
                }
            });
        }
    }

    getRiskColor(riskLevel) {
        switch (riskLevel) {
            case 'Low': return '#28a745';
            case 'Medium': return '#ffc107';
            case 'High': return '#fd7e14';
            case 'Very High': return '#dc3545';
            default: return '#6c757d';
        }
    }

    async searchBarangay() {
        const searchInput = document.getElementById('barangaySearch');
        const searchTerm = searchInput.value.trim();
        const searchResults = document.getElementById('searchResults');
        const resultCount = document.getElementById('resultCount');
        const nearestShelters = document.getElementById('nearestShelters');

        if (searchTerm === '') {
            // Clear search and show all shelters
            this.clearSearch();
            return;
        }

        // Show loading state
        nearestShelters.innerHTML = `
            <div class="search-loading">
                <div class="spinner"></div>
                <span>Searching for "${searchTerm}"...</span>
            </div>
        `;

        try {
            const response = await fetch(`app/apiShelters.php?search=${encodeURIComponent(searchTerm)}`);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();

            if (data.success && Array.isArray(data.data)) {
                if (data.data.length > 0) {
                    // Normalize and validate coordinates
                    const results = data.data.map(r => ({
                        ...r,
                        latitude: parseFloat(r.latitude),
                        longitude: parseFloat(r.longitude)
                    }));

                    // Filter only valid PH coordinates
                    const valid = results.filter(r =>
                        Number.isFinite(r.latitude) &&
                        Number.isFinite(r.longitude) &&
                        r.latitude >= 4 && r.latitude <= 21 &&
                        r.longitude >= 116 && r.longitude <= 127
                    );

                    // Check for exact barangay name match
                    const exactMatch = valid.find(
                        r => (r.barangay || '').toLowerCase() === searchTerm.toLowerCase()
                    );

                if (exactMatch) {
                    // Center coordinates
                    const center = L.latLng(exactMatch.latitude, exactMatch.longitude);

                    // Compute pixel offset to shift slightly to the right
                    const mapSize = this.map.getSize();
                    const offsetX = mapSize.x * 0.15; // shift 15% of map width to the right
                    const offsetPoint = this.map.project(center).add([offsetX, 0]);
                    const adjustedCenter = this.map.unproject(offsetPoint);

                    // Smooth zoom to adjusted center
                    this.map.flyTo(adjustedCenter, 16, {
                        animate: true,
                        duration: 1,
                        easeLinearity: 0.5
                    });

                    this.showShelterInfo(exactMatch);

                } else if (valid.length > 0) {
                    // Fit to all barangays
                    const bounds = L.latLngBounds(valid.map(v => [v.latitude, v.longitude]));
                    this.map.flyToBounds(bounds, {
                        padding: [40, 40],
                        animate: true,
                        duration: 1,
                        easeLinearity: 0.5
                    });

                    // Then correct center to shift right
                    const center = bounds.getCenter();
                    const mapSize = this.map.getSize();
                    const offsetX = mapSize.x * 0.15; // same right offset
                    const offsetPoint = this.map.project(center).add([offsetX, 0]);
                    const adjustedCenter = this.map.unproject(offsetPoint);

                    this.map.panTo(adjustedCenter, { animate: true, duration: 1 });
                    this.showShelterInfo(valid[0]);

                } else {
                    this.showSearchNoResults(searchTerm);
                    return;
                }

                    // Display results
                    this.displaySearchResults(results, searchTerm);
                    if (resultCount) resultCount.textContent = data.count || results.length;
                    if (searchResults) searchResults.style.display = 'block';
                } else {
                    this.showSearchNoResults(searchTerm);
                }
            } else {
                this.showSearchError(data.error || 'No shelters found for this search term.');
            }
        } catch (error) {
            console.error('Search error:', error);
            if (error.message.includes('HTTP 500')) {
                this.showSearchError('Database connection error. Please check if MySQL is running.');
            } else if (error.message.includes('fetch')) {
                this.showSearchError('Network error. Please check your internet connection.');
            } else {
                this.showSearchError('Error performing search. Please try again.');
            }
        }
    }

    // Auto-search with debounce
    autoSearch() {
        const searchInput = document.getElementById('barangaySearch');
        const searchTerm = searchInput.value.trim();

        if (this.autoSearchTimeout) {
            clearTimeout(this.autoSearchTimeout);
        }

        if (searchTerm === '') {
            this.clearSearch();
            return;
        }

        // Debounce search execution
        this.autoSearchTimeout = setTimeout(() => {
            this.searchBarangay();
        }, 500);
    }

    displaySearchResults(shelters, searchTerm) {
        const nearestShelters = document.getElementById('nearestShelters');

        if (shelters.length === 0) {
            nearestShelters.innerHTML = `
                <div class="alert alert-warning" role="alert">
                    <i class="fas fa-exclamation-triangle"></i> No shelters found for "${searchTerm}"
                </div>
            `;
            return;
        }

        let html = `<h6 class="mb-3"><i class="fas fa-search"></i> Search Results for "${searchTerm}"</h6>`;

        shelters.forEach(shelter => {
            const highlightedBarangay = this.highlightSearchTerm(shelter.barangay || '', searchTerm);
            const highlightedOwner = this.highlightSearchTerm(shelter.owner_name || '', searchTerm);

            html += `
                <div class="shelter-search-result" onclick="evacuationSystem.selectSearchedShelter(${shelter.shelter_id})">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <strong>${highlightedBarangay}</strong><br>
                            <small class="text-muted">Owner: ${highlightedOwner}</small>
                        </div>
                        <span class="badge ${shelter.is_safe_shelter ? 'bg-success' : 'bg-danger'}">
                            ${shelter.is_safe_shelter ? 'Safe' : 'Not Safe'}
                        </span>
                    </div>
                    <div class="mt-2">
                        <small>
                            <i class="fas fa-users"></i> Capacity: ${shelter.capacity || 'N/A'}<br>
                            <i class="fas fa-exclamation-triangle"></i> Risk Level: ${shelter.risk_level || 'Low'}<br>
                            <i class="fas fa-map-marker-alt"></i> ${shelter.latitude?.toFixed(6)}, ${shelter.longitude?.toFixed(6)}
                        </small>
                    </div>
                </div>
            `;
        });

        html += `
            <button class="btn btn-outline-light btn-sm w-100 mt-2" onclick="evacuationSystem.clearSearch()">
                <i class="fas fa-times"></i> Clear Search
            </button>
        `;

        nearestShelters.innerHTML = html;
    }

    highlightSearchTerm(text, searchTerm) {
        if (!searchTerm || !text) return text;
        const regex = new RegExp(`(${searchTerm})`, 'gi');
        return text.replace(regex, '<span class="search-highlight">$1</span>');
    }

    selectSearchedShelter(shelterId) {
        const shelter = this.shelters?.find(s => s.shelter_id === shelterId);
        if (shelter) {
            this.map.setView([shelter.latitude, shelter.longitude], 15);
            this.showShelterInfo(shelter);

            const results = document.querySelectorAll('.shelter-search-result');
            results.forEach(result => result.classList.remove('selected'));

            // Highlight clicked result safely
            const selected = event?.target?.closest('.shelter-search-result');
            if (selected) selected.classList.add('selected');
        }
    }

    clearSearch() {
        const searchInput = document.getElementById('barangaySearch');
        const searchResults = document.getElementById('searchResults');
        
        searchInput.value = '';
        searchResults.style.display = 'none';
        
        // Reload original nearest shelters
        this.updateNearestShelters();
    }

    showSearchError(message) {
        const nearestShelters = document.getElementById('nearestShelters');
        nearestShelters.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <i class="fas fa-exclamation-circle"></i> ${message}
            </div>
        `;
    }

    showSearchNoResults(searchTerm) {
        const nearestShelters = document.getElementById('nearestShelters');
        nearestShelters.innerHTML = `
            <div class="search-empty">
                <i class="fas fa-search"></i>
                <h6>No shelters found for "${searchTerm}"</h6>
                <p class="text-muted">Try searching for a different barangay or owner name.</p>
                <div class="mt-3">
                    <button onclick="evacuationSystem.clearSearch()" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-times"></i> Clear Search
                    </button>
                    <button onclick="evacuationSystem.showAllShelters()" class="btn btn-primary btn-sm ms-2">
                        <i class="fas fa-list"></i> Show All Shelters
                    </button>
                </div>
            </div>
        `;
    }

    async showAllShelters() {
        try {
            const response = await fetch('app/apiShelters.php');
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.data) {
                    this.displaySearchResults(data.data, 'all shelters');
                    const resultCount = document.getElementById('resultCount');
                    const searchResults = document.getElementById('searchResults');
                    if (resultCount && searchResults) {
                        resultCount.textContent = data.count;
                        searchResults.style.display = 'block';
                    }
                }
            }
        } catch (error) {
            console.error('Error loading all shelters:', error);
            this.showSearchError('Error loading all shelters. Please try again.');
        }
    }

    async loadSuggestions(searchTerm) {
        try {
            const response = await fetch(`app/apiSuggestions.php?q=${encodeURIComponent(searchTerm)}`);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();

            if (data.success && data.data && data.data.length > 0) {
                this.displaySuggestions(data.data, searchTerm);
            } else {
                this.hideSuggestions();
            }
        } catch (error) {
            console.error('Error loading suggestions:', error);
            this.hideSuggestions();
        }
    }

    displaySuggestions(suggestions, searchTerm) {
        const suggestionsContainer = document.getElementById('searchSuggestions');
        const suggestionsList = document.getElementById('suggestionsList');

        let html = '';
        suggestions.forEach((suggestion, index) => {
            const highlightedName = this.highlightSearchTerm(suggestion.name, searchTerm);
            const icon = suggestion.type === 'barangay' ? 'fas fa-map-marker-alt' : 'fas fa-user';
            const typeLabel = suggestion.type === 'barangay' ? 'Barangay' : 'Owner';
            
            html += `
                <div class="suggestion-item" 
                     onclick="evacuationSystem.selectSuggestion('${suggestion.name}', '${suggestion.type}')"
                     onmouseover="evacuationSystem.highlightSuggestion(${index})">
                    <div class="suggestion-icon">
                        <i class="${icon}"></i>
                    </div>
                    <div class="suggestion-text">
                        ${highlightedName}
                    </div>
                    <div class="suggestion-type">
                        ${typeLabel}
                    </div>
                </div>
            `;
        });

        suggestionsList.innerHTML = html;
        suggestionsContainer.style.display = 'block';
    }

    selectSuggestion(name, type) {
        const searchInput = document.getElementById('barangaySearch');
        searchInput.value = name;
        this.hideSuggestions();
        this.searchBarangay();
    }

    highlightSuggestion(index) {
        const suggestions = document.querySelectorAll('.suggestion-item');
        suggestions.forEach((item, i) => {
            if (i === index) {
                item.classList.add('selected');
            } else {
                item.classList.remove('selected');
            }
        });
    }

    hideSuggestions() {
        const suggestionsContainer = document.getElementById('searchSuggestions');
        suggestionsContainer.style.display = 'none';
    }

    navigateSuggestions(direction) {
        const suggestions = document.querySelectorAll('.suggestion-item');
        const currentSelected = document.querySelector('.suggestion-item.selected');
        
        if (suggestions.length === 0) return;

        let currentIndex = -1;
        if (currentSelected) {
            currentIndex = Array.from(suggestions).indexOf(currentSelected);
        }

        let newIndex;
        if (direction === 'down') {
            newIndex = currentIndex < suggestions.length - 1 ? currentIndex + 1 : 0;
        } else {
            newIndex = currentIndex > 0 ? currentIndex - 1 : suggestions.length - 1;
        }

        // Remove current selection
        suggestions.forEach(item => item.classList.remove('selected'));
        
        // Add selection to new item
        suggestions[newIndex].classList.add('selected');
        
        // Scroll into view if needed
        suggestions[newIndex].scrollIntoView({ block: 'nearest' });
    }

    // Method to handle device-specific location management
    async refreshLocationForAllDevices() {
        try {
            // Show loading message
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-sync fa-spin"></i> Refreshing Location</h6>
                    <p class="text-muted">Updating location for all devices...</p>
                </div>
            `;

            // Get current location and update database
            await this.getCurrentLocation();
            
            // Show success message
            this.showAlert('Location refreshed successfully for all devices!', 'success');
            
        } catch (error) {
            console.error('Error refreshing location:', error);
            this.showAlert('Failed to refresh location. Please try again.', 'error');
        }
    }

    // Method to check if location is recent (within last 5 minutes)
    isLocationRecent() {
        if (!this.currentLocation || !this.currentLocation.timestamp) {
            return false;
        }
        
        const fiveMinutesAgo = Date.now() - (5 * 60 * 1000);
        const locationTime = new Date(this.currentLocation.timestamp).getTime();
        
        return locationTime > fiveMinutesAgo;
    }

    // Method to suggest location refresh if needed
    suggestLocationRefresh() {
        if (!this.isLocationRecent()) {
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-info-circle"></i> Location May Be Outdated</h6>
                    <p class="text-muted">Your location data may be outdated. Consider refreshing for the most accurate information.</p>
                    <div class="mt-2">
                        <button onclick="evacuationSystem.refreshLocationForAllDevices()" class="btn btn-warning btn-sm w-100 mb-2">
                            <i class="fas fa-sync"></i> Refresh Location
                        </button>
                        <button onclick="evacuationSystem.loadCurrentLocation()" class="btn btn-outline-primary btn-sm w-100">
                            <i class="fas fa-database"></i> Use Saved Location
                        </button>
                    </div>
                </div>
            `;
        }
    }

    // Method to check current location status and provide appropriate feedback
    checkLocationStatus() {
        if (!this.currentLocation) {
            const shelterInfo = document.getElementById('nearestShelters');
            shelterInfo.innerHTML = `
                <div class="shelter-info">
                    <h6><i class="fas fa-info-circle"></i> No Location Set</h6>
                    <p class="text-muted">Please set your current location to use the evacuation system effectively.</p>
                    <div class="mt-2">
                        <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary btn-sm w-100 mb-2">
                            <i class="fas fa-location-arrow"></i> Get My Location
                        </button>
                        <button onclick="evacuationSystem.loadCurrentLocation()" class="btn btn-outline-primary btn-sm w-100">
                            <i class="fas fa-database"></i> Load Saved Location
                        </button>
                    </div>
                </div>
            `;
        } else if (!this.isLocationRecent()) {
            this.suggestLocationRefresh();
        }
    }

        // Method to show multi-device usage information
    showMultiDeviceInfo() {
        const shelterInfo = document.getElementById('nearestShelters');
        shelterInfo.innerHTML = `
            <div class="shelter-info">
                <h6><i class="fas fa-users"></i> Multi-Device System</h6>
                <p class="text-muted">This system is designed to work with multiple devices. Your location will be shared and updated for all users.</p>
                <div class="mt-2">
                    <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary btn-sm w-100 mb-2">
                        <i class="fas fa-location-arrow"></i> Update My Location
                    </button>
                    <button onclick="evacuationSystem.loadCurrentLocation()" class="btn btn-outline-primary btn-sm w-100 mb-2">
                        <i class="fas fa-database"></i> Load Shared Location
                    </button>
                    <button onclick="evacuationSystem.refreshLocationForAllDevices()" class="btn btn-warning btn-sm w-100">
                        <i class="fas fa-sync"></i> Refresh Shared Location
                    </button>
                </div>
                <div class="mt-2">
                    <small class="text-muted">
                        <i class="fas fa-info-circle"></i> 
                        Location updates are automatically shared across all devices using this system.
                    </small>
                </div>
            </div>
        `;
    }

    // Method to show welcome message for multi-device system
    showWelcomeMessage() {
        // Only show welcome message if no location is set
        if (!this.currentLocation) {
            setTimeout(() => {
                const shelterInfo = document.getElementById('nearestShelters');
                shelterInfo.innerHTML = `
                    <div class="shelter-info">
                        <h6><i class="fas fa-handshake"></i> Welcome to Multi-Device Evacuation System</h6>
                        <p class="text-muted">This system is designed to work seamlessly with multiple devices. Your location will be safely shared and updated for all users.</p>
                        <div class="mt-2">
                            <button onclick="evacuationSystem.getCurrentLocation()" class="btn btn-primary btn-sm w-100 mb-2">
                                <i class="fas fa-location-arrow"></i> Set My Location
                            </button>
                            <button onclick="evacuationSystem.loadCurrentLocation()" class="btn btn-outline-primary btn-sm w-100 mb-2">
                                <i class="fas fa-database"></i> Use Shared Location
                            </button>
                            <button onclick="evacuationSystem.showMultiDeviceInfo()" class="btn btn-info btn-sm w-100 mb-2">
                                <i class="fas fa-info-circle"></i> Learn More
                            </button>
                            <a href="ml-dashboard.html" class="btn btn-warning btn-sm w-100" target="_blank">
                                <i class="fas fa-brain"></i> AI Flood Prediction
                            </a>
                        </div>
                        <div class="mt-2">
                            <small class="text-success">
                                <i class="fas fa-shield-alt"></i> 
                                Your location is shared securely and only used for evacuation purposes
                            </small>
                        </div>
                    </div>
                `;
            }, 1000); // Show after 1 second delay
        }
    }

    // ============================================
    // RANDOM FOREST MACHINE LEARNING METHODS
    // ============================================

    /**
     * Initialize Random Forest model with evacuation data
     */
    initializeRandomForest() {
        if (this.trainingInProgress) return;
        
        this.trainingInProgress = true;
        
        // Generate minimal training data for faster processing
        this.generateOptimizedTrainingData();
        
        // Train the model asynchronously
        setTimeout(() => {
            this.trainRandomForest();
        }, 100);
    }

    /**
     * Generate training data for Random Forest
     */
    generateOptimizedTrainingData() {
        const trainingData = [];
        
        // Generate minimal training data for faster processing
        const sampleCount = Math.min(this.shelters.length * 2, 50); // Max 50 samples
        
        for (let i = 0; i < sampleCount; i++) {
            const shelter = this.shelters[i % this.shelters.length];
            const sample = {
                population_density: this.generatePopulationDensity(shelter.barangay),
                shelter_capacity: shelter.capacity || Math.floor(Math.random() * 50) + 10,
                distance_to_shelter: Math.random() * 10,
                weather_condition: ['sunny', 'cloudy', 'rainy', 'stormy'][Math.floor(Math.random() * 4)],
                time_of_day: Math.random() * 24,
                season: Math.random() > 0.5 ? 'dry' : 'wet',
                flood_risk: shelter.flood_zone === 'Yes' ? 1 : 0,
                landslide_risk: shelter.landslide_zone === 'Yes' ? 1 : 0,
                typhoon_risk: shelter.typhoon_zone === 'Yes' ? 1 : 0
            };

            // Determine risk level based on features
            const riskLevel = this.calculateRiskLevel(sample);
            
            trainingData.push({
                features: sample,
                risk_level: riskLevel
            });
        }

        this.trainingData = trainingData;
    }

    generateTrainingData() {
        // Fallback method - use optimized version
        this.generateOptimizedTrainingData();
    }

    /**
     * Train the Random Forest model
     */
    trainRandomForest() {
        if (this.trainingData.length === 0) {
            this.trainingInProgress = false;
            return;
        }

        try {
            // Prepare training data
            const X = this.trainingData.map(sample => sample.features);
            const y = this.trainingData.map(sample => sample.risk_level);

            // Train the model with timeout to prevent blocking
            const trainingPromise = new Promise((resolve) => {
                setTimeout(() => {
                    this.randomForest.train(X, y);
                    this.isModelTrained = true;
                    this.trainingInProgress = false;
                    resolve();
                }, 50);
            });
        } catch (error) {
            this.trainingInProgress = false;
        }
    }

    /**
     * Predict evacuation risk using Random Forest
     */
    predictEvacuationRisk(userLocation, targetShelter) {
        if (!this.isModelTrained) {
            return { prediction: 'MEDIUM', confidence: 50 };
        }

        // Prepare input features
        const features = {
            population_density: this.getPopulationDensity(userLocation),
            shelter_capacity: targetShelter.capacity || 20,
            distance_to_shelter: this.calculateDistance(
                userLocation.latitude, userLocation.longitude,
                targetShelter.latitude, targetShelter.longitude
            ),
            weather_condition: this.getCurrentWeatherCondition(),
            time_of_day: this.getCurrentTimeOfDay(),
            season: this.getCurrentSeason(),
            flood_risk: targetShelter.flood_zone === 'Yes' ? 1 : 0,
            landslide_risk: targetShelter.landslide_zone === 'Yes' ? 1 : 0,
            typhoon_risk: targetShelter.typhoon_zone === 'Yes' ? 1 : 0
        };

        // Make prediction
        const prediction = this.randomForest.predict(features);
        return prediction;
    }

    /**
     * Display Random Forest prediction results
     */
    displayRandomForestResults(prediction, shelterName) {
        const modal = document.getElementById('randomForestModal');
        if (!modal) return;

        // Update prediction results
        const predictionElement = modal.querySelector('#mlPredictionResult');
        const confidenceElement = modal.querySelector('#mlConfidenceScore');
        const votesElement = modal.querySelector('#mlTreeVotes');

        if (predictionElement) {
            predictionElement.innerHTML = `
                <div class="prediction-result">
                    <div class="risk-badge ${prediction.prediction.toLowerCase()}">
                        ${prediction.prediction} RISK
                    </div>
                    <div class="shelter-name">${shelterName}</div>
                </div>
            `;
        }

        if (confidenceElement) {
            confidenceElement.innerHTML = `
                <div class="confidence-score">
                    <span class="score">${prediction.confidence.toFixed(1)}%</span>
                    <span class="label">Confidence</span>
                </div>
            `;
        }

        if (votesElement) {
            const votesHtml = Object.entries(prediction.treeVotes)
                .map(([risk, count]) => `
                    <div class="vote-item">
                        <span class="risk-label ${risk.toLowerCase()}">${risk}</span>
                        <span class="vote-count">${count} trees</span>
                    </div>
                `).join('');
            
            votesElement.innerHTML = `
                <div class="tree-votes">
                    <h6>Tree Voting Results:</h6>
                    ${votesHtml}
            </div>
        `;
        }
    }

    /**
     * Generate synthetic data for training
     */
    generatePopulationDensity(barangay) {
        // Simulate population density based on barangay
        const baseDensity = {
            'Antipolo Del Norte': 1200,
            'Barangay Central': 800,
            'Barangay Poblacion': 1500,
            'Barangay Riverside': 600
        };
        
        return (baseDensity[barangay] || 1000) + Math.random() * 500;
    }

    generateDistanceToShelter() {
        return Math.random() * 10; // 0-10 km
    }

    generateWeatherCondition() {
        const conditions = ['sunny', 'cloudy', 'rainy', 'stormy'];
        return conditions[Math.floor(Math.random() * conditions.length)];
    }

    generateTimeOfDay() {
        return Math.random() * 24; // 0-24 hours
    }

    generateSeason() {
        const seasons = ['dry', 'wet'];
        return seasons[Math.floor(Math.random() * seasons.length)];
    }

    /**
     * Calculate risk level based on features
     */
    calculateRiskLevel(sample) {
        let riskScore = 0;

        // Population density factor
        if (sample.population_density > 1200) riskScore += 2;
        else if (sample.population_density > 800) riskScore += 1;

        // Shelter capacity factor
        if (sample.shelter_capacity < 20) riskScore += 2;
        else if (sample.shelter_capacity < 40) riskScore += 1;

        // Distance factor
        if (sample.distance_to_shelter > 5) riskScore += 2;
        else if (sample.distance_to_shelter > 2) riskScore += 1;

        // Weather factor
        if (sample.weather_condition === 'stormy') riskScore += 3;
        else if (sample.weather_condition === 'rainy') riskScore += 2;

        // Hazard factors
        riskScore += sample.flood_risk * 2;
        riskScore += sample.landslide_risk * 2;
        riskScore += sample.typhoon_risk * 2;

        // Time factor (night time is riskier)
        if (sample.time_of_day < 6 || sample.time_of_day > 20) riskScore += 1;

        // Determine risk level
        if (riskScore >= 8) return 'CRITICAL';
        else if (riskScore >= 6) return 'HIGH';
        else if (riskScore >= 3) return 'MEDIUM';
        else return 'LOW';
    }

    /**
     * Get real-time data for prediction
     */
    getPopulationDensity(location) {
        // Simulate population density lookup
        return 1000 + Math.random() * 500;
    }

    getCurrentWeatherCondition() {
        // Simulate weather API call
        const conditions = ['sunny', 'cloudy', 'rainy', 'stormy'];
        return conditions[Math.floor(Math.random() * conditions.length)];
    }

    getCurrentTimeOfDay() {
        return new Date().getHours() + Math.random();
    }

    getCurrentSeason() {
        const month = new Date().getMonth();
        return (month >= 6 && month <= 11) ? 'wet' : 'dry';
    }

    /**
     * Run Random Forest analysis for a specific route
     */
    async runRandomForestAnalysis(startLat, startLng, endLat, endLng, shelterName) {
        if (!this.isModelTrained) {
            this.showAlert('⚠️ Random Forest model is still training. Please wait...', 'warning');
            return;
        }

        const userLocation = { latitude: startLat, longitude: startLng };
        const targetShelter = {
            latitude: endLat,
            longitude: endLng,
            capacity: 25,
            flood_zone: 'Yes',
            landslide_zone: 'No',
            typhoon_zone: 'Yes'
        };

        // Make prediction
        const prediction = this.predictEvacuationRisk(userLocation, targetShelter);
        
        // Display results
        this.displayRandomForestResults(prediction, shelterName);
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('randomForestModal'));
        modal.show();

        return prediction;
    }

}

// Global variable for evacuation system
let evacuationSystem;

// Initialize the system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    evacuationSystem = new EvacuationSystem();
});