<?php
require_once __DIR__ . '/Db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!isset($_FILES['file'])) {
    echo json_encode(['success' => false, 'message' => 'No file uploaded']);
    exit;
}

$file = $_FILES['file'];
$fileName = $file['name'];
$fileTmpName = $file['tmp_name'];
$fileError = $file['error'];

if ($fileError !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'File upload error']);
    exit;
}

// Check file extension
$fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
if (!in_array($fileExt, ['csv', 'json'])) {
    echo json_encode(['success' => false, 'message' => 'Only CSV and JSON files are allowed']);
    exit;
}

try {
    $pdo = Db::connect();
    $pdo->beginTransaction();
    
    // Check if user wants to clear existing data
    $clearExisting = isset($_POST['clear_existing']) && $_POST['clear_existing'] === 'true';
    
    if ($clearExisting) {
        $pdo->exec("DELETE FROM shelters");
    }
    
    $inserted = 0;
    $errors = [];
    
    if ($fileExt === 'csv') {
        // Parse CSV file
        $handle = fopen($fileTmpName, 'r');
        
        // Get headers from first line
        $headers = fgetcsv($handle);
        if (!$headers) {
            throw new Exception('Invalid CSV format - no headers found');
        }
        
        // Clean headers
        $headers = array_map('trim', $headers);
        
        // Prepare insert statement
        $sql = "INSERT INTO shelters (
            barangay, owner_name, capacity, typhoon_zone, flood_zone, 
            landslide_zone, liquefaction_zone, storm_surge_zone, elevation, 
            latitude, longitude, building_material_type, building_condition, 
            water_supply, electricity, road_condition, estimated_travel_time, 
            near_main_road, is_safe_shelter
        ) VALUES (
            :barangay, :owner_name, :capacity, :typhoon_zone, :flood_zone, 
            :landslide_zone, :liquefaction_zone, :storm_surge_zone, :elevation, 
            :latitude, :longitude, :building_material_type, :building_condition, 
            :water_supply, :electricity, :road_condition, :estimated_travel_time, 
            :near_main_road, :is_safe_shelter
        )";
        
        $stmt = $pdo->prepare($sql);
        
        // Process each row
        $rowNum = 1;
        while (($row = fgetcsv($handle)) !== false) {
            $rowNum++;
            
            if (count($row) !== count($headers)) {
                $errors[] = "Row $rowNum: Column count mismatch";
                continue;
            }
            
            // Combine headers with row values
            $data = array_combine($headers, $row);
            
            try {
                // Validate and prepare data (handle both formats)
                $params = [
                    ':barangay' => trim($data['Barangay'] ?? $data['barangay'] ?? ''),
                    ':owner_name' => trim($data['Owner_Name'] ?? $data['owner_name'] ?? ''),
                    ':capacity' => trim($data['Capacity'] ?? $data['capacity'] ?? '0'),
                    ':typhoon_zone' => strtolower(trim($data['Typhoon_Zone'] ?? $data['typhoon_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':flood_zone' => strtolower(trim($data['Flood_Zone'] ?? $data['flood_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':landslide_zone' => strtolower(trim($data['Landslide_Zone'] ?? $data['landslide_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':liquefaction_zone' => strtolower(trim($data['Liquefaction_Zone'] ?? $data['liquefaction_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':storm_surge_zone' => strtolower(trim($data['Storm_Surge_Zone'] ?? $data['storm_surge_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':elevation' => floatval(str_replace(['m', 'meters', ' '], '', $data['Elevation'] ?? $data['elevation'] ?? 0)),
                    ':latitude' => floatval($data['Latitude'] ?? $data['latitude'] ?? 0),
                    ':longitude' => floatval($data['Longitude'] ?? $data['longitude'] ?? 0),
                    ':building_material_type' => trim($data['Building_Material_Type'] ?? $data['building_material_type'] ?? ''),
                    ':building_condition' => trim($data['Building_Condition'] ?? $data['building_condition'] ?? ''),
                    ':water_supply' => trim($data['Water_Supply'] ?? $data['water_supply'] ?? ''),
                    ':electricity' => trim($data['Electricity'] ?? $data['electricity'] ?? ''),
                    ':road_condition' => trim($data['Road_Condition'] ?? $data['road_condition'] ?? ''),
                    ':estimated_travel_time' => trim($data['Estimated_Travel_time'] ?? $data['estimated_travel_time'] ?? '0'),
                    ':near_main_road' => strtolower(trim($data['Near_Main_Road'] ?? $data['near_main_road'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':is_safe_shelter' => (strtolower(trim($data['Is_Safe_Shelter'] ?? $data['is_safe_shelter'] ?? '1')) === 'yes' || trim($data['Is_Safe_Shelter'] ?? $data['is_safe_shelter'] ?? '1') === '1') ? 1 : 0
                ];
                
                // Validate coordinates
                if ($params[':latitude'] < -90 || $params[':latitude'] > 90 ||
                    $params[':longitude'] < -180 || $params[':longitude'] > 180 ||
                    ($params[':latitude'] == 0 && $params[':longitude'] == 0)) {
                    $errors[] = "Row $rowNum: Invalid coordinates";
                    continue;
                }
                
                $stmt->execute($params);
                $inserted++;
                
            } catch (Exception $e) {
                $errors[] = "Row $rowNum: " . $e->getMessage();
            }
        }
        
        fclose($handle);
        
    } else if ($fileExt === 'json') {
        // Parse JSON file
        $jsonContent = file_get_contents($fileTmpName);
        $jsonData = json_decode($jsonContent, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid JSON format');
        }
        
        // Handle both array and object with shelters property
        $shelters = [];
        if (isset($jsonData['shelters']) && is_array($jsonData['shelters'])) {
            $shelters = $jsonData['shelters'];
        } else if (is_array($jsonData)) {
            $shelters = $jsonData;
        } else {
            throw new Exception('Invalid JSON structure');
        }
        
        // Prepare insert statement
        $sql = "INSERT INTO shelters (
            barangay, owner_name, capacity, typhoon_zone, flood_zone, 
            landslide_zone, liquefaction_zone, storm_surge_zone, elevation, 
            latitude, longitude, building_material_type, building_condition, 
            water_supply, electricity, road_condition, estimated_travel_time, 
            near_main_road, is_safe_shelter
        ) VALUES (
            :barangay, :owner_name, :capacity, :typhoon_zone, :flood_zone, 
            :landslide_zone, :liquefaction_zone, :storm_surge_zone, :elevation, 
            :latitude, :longitude, :building_material_type, :building_condition, 
            :water_supply, :electricity, :road_condition, :estimated_travel_time, 
            :near_main_road, :is_safe_shelter
        )";
        
        $stmt = $pdo->prepare($sql);
        
        foreach ($shelters as $index => $shelter) {
            try {
                $params = [
                    ':barangay' => trim($shelter['Barangay'] ?? $shelter['barangay'] ?? ''),
                    ':owner_name' => trim($shelter['Owner_Name'] ?? $shelter['owner_name'] ?? ''),
                    ':capacity' => trim($shelter['Capacity'] ?? $shelter['capacity'] ?? '0'),
                    ':typhoon_zone' => strtolower(trim($shelter['Typhoon_Zone'] ?? $shelter['typhoon_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':flood_zone' => strtolower(trim($shelter['Flood_Zone'] ?? $shelter['flood_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':landslide_zone' => strtolower(trim($shelter['Landslide_Zone'] ?? $shelter['landslide_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':liquefaction_zone' => strtolower(trim($shelter['Liquefaction_Zone'] ?? $shelter['liquefaction_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':storm_surge_zone' => strtolower(trim($shelter['Storm_Surge_Zone'] ?? $shelter['storm_surge_zone'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':elevation' => floatval(str_replace(['m', 'meters', ' '], '', $shelter['Elevation'] ?? $shelter['elevation'] ?? 0)),
                    ':latitude' => floatval($shelter['Latitude'] ?? $shelter['latitude'] ?? 0),
                    ':longitude' => floatval($shelter['Longitude'] ?? $shelter['longitude'] ?? 0),
                    ':building_material_type' => trim($shelter['Building_Material_Type'] ?? $shelter['building_material_type'] ?? ''),
                    ':building_condition' => trim($shelter['Building_Condition'] ?? $shelter['building_condition'] ?? ''),
                    ':water_supply' => trim($shelter['Water_Supply'] ?? $shelter['water_supply'] ?? ''),
                    ':electricity' => trim($shelter['Electricity'] ?? $shelter['electricity'] ?? ''),
                    ':road_condition' => trim($shelter['Road_Condition'] ?? $shelter['road_condition'] ?? ''),
                    ':estimated_travel_time' => trim($shelter['Estimated_Travel_time'] ?? $shelter['estimated_travel_time'] ?? '0'),
                    ':near_main_road' => strtolower(trim($shelter['Near_Main_Road'] ?? $shelter['near_main_road'] ?? 'No')) === 'yes' ? 'Yes' : 'No',
                    ':is_safe_shelter' => (strtolower(trim($shelter['Is_Safe_Shelter'] ?? $shelter['is_safe_shelter'] ?? '1')) === 'yes' || trim($shelter['Is_Safe_Shelter'] ?? $shelter['is_safe_shelter'] ?? '1') === '1') ? 1 : 0
                ];
                
                // Validate coordinates
                if ($params[':latitude'] < -90 || $params[':latitude'] > 90 ||
                    $params[':longitude'] < -180 || $params[':longitude'] > 180 ||
                    ($params[':latitude'] == 0 && $params[':longitude'] == 0)) {
                    $errors[] = "Shelter " . ($index + 1) . ": Invalid coordinates";
                    continue;
                }
                
                $stmt->execute($params);
                $inserted++;
                
            } catch (Exception $e) {
                $errors[] = "Shelter " . ($index + 1) . ": " . $e->getMessage();
            }
        }
    }
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => "Successfully imported $inserted shelters" . (count($errors) > 0 ? " with " . count($errors) . " errors" : ""),
        'inserted' => $inserted,
        'errors' => $errors
    ]);
    
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}

