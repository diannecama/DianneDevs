<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    // Use the Db class for database connection
    require_once 'Db.php';
    $pdo = Db::getConnection();

    // Check if search parameter is provided
    $searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
    
    if (!empty($searchTerm)) {
        // Search by barangay name or owner name
        $stmt = $pdo->prepare("
            SELECT 
                shelter_id, barangay, owner_name, capacity,
                typhoon_zone, flood_zone, landslide_zone, storm_surge_zone,
                elevation, latitude, longitude,
                building_material_type, building_condition, water_supply, electricity,
                road_condition, estimated_travel_time, near_main_road, is_safe_shelter, is_active,
                created_at, updated_at
            FROM shelters 
            WHERE is_active = 1 
            AND (barangay LIKE :search OR owner_name LIKE :search)
            ORDER BY barangay ASC, owner_name ASC
        ");
        $searchParam = '%' . $searchTerm . '%';
        $stmt->bindParam(':search', $searchParam, PDO::PARAM_STR);
    } else {
        // Get all active shelters with complete categorization
        $stmt = $pdo->prepare("
            SELECT 
                shelter_id, barangay, owner_name, capacity,
                typhoon_zone, flood_zone, landslide_zone, storm_surge_zone,
                elevation, latitude, longitude,
                building_material_type, building_condition, water_supply, electricity,
                road_condition, estimated_travel_time, near_main_road, is_safe_shelter, is_active,
                created_at, updated_at
            FROM shelters 
            WHERE is_active = 1
            ORDER BY barangay ASC, owner_name ASC
        ");
    }

    $stmt->execute();
    $shelters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Add calculated fields and categorize data
    foreach ($shelters as &$shelter) {
        $capacity = (int) $shelter['capacity'];

        // Determine capacity status based on shelter type
        if ($shelter['is_safe_shelter']) {
            $shelter['capacity_status'] = 'available';
        } else {
            $shelter['capacity_status'] = 'not_safe';
        }

        // Calculate risk level based on hazard zones
        $riskFactors = 0;
        if ($shelter['typhoon_zone'] === 'Yes') $riskFactors++;
        if ($shelter['flood_zone'] === 'Yes') $riskFactors++;
        if ($shelter['landslide_zone'] === 'Yes') $riskFactors++;
        if ($shelter['storm_surge_zone'] === 'Yes') $riskFactors++;
        
        $shelter['risk_level'] = calculateRiskLevel($riskFactors);
        $shelter['risk_factors'] = $riskFactors;

        // Convert numeric strings to numbers
        $shelter['shelter_id'] = (int) $shelter['shelter_id'];
        $shelter['capacity'] = (int) $shelter['capacity'];
        $shelter['latitude'] = (float) $shelter['latitude'];
        $shelter['longitude'] = (float) $shelter['longitude'];
        $shelter['elevation'] = (float) $shelter['elevation'];
        $shelter['estimated_travel_time'] = (int) $shelter['estimated_travel_time'];
        $shelter['near_main_road'] = $shelter['near_main_road'] === 'Yes';
        $shelter['is_safe_shelter'] = (bool) $shelter['is_safe_shelter'];
        $shelter['is_active'] = (bool) $shelter['is_active'];
    }

    echo json_encode([
        'success' => true,
        'data' => $shelters,
        'timestamp' => date('Y-m-d H:i:s'),
        'count' => count($shelters),
        'searchTerm' => $searchTerm,
        'message' => !empty($searchTerm) ? "Found " . count($shelters) . " shelters for '$searchTerm'" : "Retrieved all shelters"
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
        'details' => 'Please check if MySQL is running and the database exists'
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
        'details' => 'An unexpected error occurred'
    ]);
}

// Helper function to calculate risk level
function calculateRiskLevel($riskFactors) {
    if ($riskFactors === 0) return 'Low';
    if ($riskFactors <= 2) return 'Medium';
    if ($riskFactors <= 4) return 'High';
    return 'Very High';
}
?>