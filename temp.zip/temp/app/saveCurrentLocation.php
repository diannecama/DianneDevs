<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    require_once 'Db.php';
    $pdo = Db::getConnection();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get POST data
    $input = json_decode(file_get_contents('php://input'), true);
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $latitude = isset($input['latitude']) ? (float) $input['latitude'] : null;
        $longitude = isset($input['longitude']) ? (float) $input['longitude'] : null;
        
        if ($latitude === null || $longitude === null) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'Latitude and longitude are required',
                'timestamp' => date('Y-m-d H:i:s'),
            ]);
            exit;
        }

        // Validate coordinates
        if ($latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'Invalid coordinates provided',
                'timestamp' => date('Y-m-d H:i:s'),
            ]);
            exit;
        }

        // Check if there's an existing location record
        $checkStmt = $pdo->prepare("SELECT id FROM mycurrentlocation ORDER BY created_at DESC LIMIT 1");
        $checkStmt->execute();
        $existingRecord = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingRecord) {
            // Update existing record
            $stmt = $pdo->prepare("
                UPDATE mycurrentlocation 
                SET latitude = :latitude, longitude = :longitude, updated_at = CURRENT_TIMESTAMP 
                WHERE id = :id
            ");
            
            $stmt->bindParam(':latitude', $latitude, PDO::PARAM_STR);
            $stmt->bindParam(':longitude', $longitude, PDO::PARAM_STR);
            $stmt->bindParam(':id', $existingRecord['id'], PDO::PARAM_INT);
            $stmt->execute();
            
            $recordId = $existingRecord['id'];
            $action = 'updated';
        } else {
            // Insert new record if none exists
            $stmt = $pdo->prepare("
                INSERT INTO mycurrentlocation (latitude, longitude) 
                VALUES (:latitude, :longitude)
            ");
            
            $stmt->bindParam(':latitude', $latitude, PDO::PARAM_STR);
            $stmt->bindParam(':longitude', $longitude, PDO::PARAM_STR);
            $stmt->execute();
            
            $recordId = $pdo->lastInsertId();
            $action = 'inserted';
        }
        
        echo json_encode([
            'success' => true,
            'message' => "Location $action successfully",
            'data' => [
                'id' => (int) $recordId,
                'latitude' => $latitude,
                'longitude' => $longitude,
                'action' => $action,
                'created_at' => date('Y-m-d H:i:s')
            ],
            'timestamp' => date('Y-m-d H:i:s'),
        ]);
        
    } else {
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'error' => 'Method not allowed. Use POST.',
            'timestamp' => date('Y-m-d H:i:s'),
        ]);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
    ]);
}
?>
