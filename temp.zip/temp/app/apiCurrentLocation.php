<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    // Use the Db class for database connection
    require_once 'Db.php';
    $pdo = Db::getConnection();

    // Get the latest current location
    $stmt = $pdo->prepare("
        SELECT id, latitude, longitude, created_at, updated_at
        FROM mycurrentlocation 
        ORDER BY updated_at DESC, created_at DESC 
        LIMIT 1
    ");
    $stmt->execute();
    $location = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($location) {
        // Convert numeric strings to numbers
        $location['id'] = (int) $location['id'];
        $location['latitude'] = (float) $location['latitude'];
        $location['longitude'] = (float) $location['longitude'];
        
        echo json_encode([
            'success' => true,
            'data' => $location,
            'timestamp' => date('Y-m-d H:i:s'),
            'message' => 'Current location retrieved successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'No location data found',
            'timestamp' => date('Y-m-d H:i:s'),
            'message' => 'Please set your current location first'
        ]);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
        'details' => 'Please check if MySQL is running and the database exists'
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
        'details' => 'An unexpected error occurred'
    ]);
}
?>
