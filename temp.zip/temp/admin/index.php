<?php
session_start();
if (empty($_SESSION['is_admin'])) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../app/Db.php';
$pdo = Db::getConnection();

// Handle CRUD actions
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'create') {
        $stmt = $pdo->prepare('INSERT INTO shelters (barangay, owner_name, capacity, typhoon_zone, flood_zone, landslide_zone, liquefaction_zone, storm_surge_zone, elevation, latitude, longitude, building_material_type, building_condition, water_supply, electricity, road_condition, estimated_travel_time, near_main_road, is_safe_shelter, is_active, created_at) VALUES (:barangay, :owner_name, :capacity, :typhoon_zone, :flood_zone, :landslide_zone, :liquefaction_zone, :storm_surge_zone, :elevation, :latitude, :longitude, :building_material_type, :building_condition, :water_supply, :electricity, :road_condition, :estimated_travel_time, :near_main_road, :is_safe_shelter, :is_active, NOW())');
        $stmt->execute([
            ':barangay' => $_POST['barangay'],
            ':owner_name' => $_POST['owner_name'],
            ':capacity' => (int)$_POST['capacity'],
            ':typhoon_zone' => $_POST['typhoon_zone'],
            ':flood_zone' => $_POST['flood_zone'],
            ':landslide_zone' => $_POST['landslide_zone'],
            ':liquefaction_zone' => $_POST['liquefaction_zone'],
            ':storm_surge_zone' => $_POST['storm_surge_zone'],
            ':elevation' => (float)$_POST['elevation'],
            ':latitude' => (float)$_POST['latitude'],
            ':longitude' => (float)$_POST['longitude'],
            ':building_material_type' => $_POST['building_material_type'],
            ':building_condition' => $_POST['building_condition'],
            ':water_supply' => $_POST['water_supply'],
            ':electricity' => $_POST['electricity'],
            ':road_condition' => $_POST['road_condition'],
            ':estimated_travel_time' => (int)$_POST['estimated_travel_time'],
            ':near_main_road' => $_POST['near_main_road'],
            ':is_safe_shelter' => (int)$_POST['is_safe_shelter'],
            ':is_active' => (int)$_POST['is_active'],
        ]);
        $message = 'Shelter created';
    }

    if ($action === 'update') {
        $stmt = $pdo->prepare('UPDATE shelters SET barangay=:barangay, owner_name=:owner_name, capacity=:capacity, typhoon_zone=:typhoon_zone, flood_zone=:flood_zone, landslide_zone=:landslide_zone, liquefaction_zone=:liquefaction_zone, storm_surge_zone=:storm_surge_zone, elevation=:elevation, latitude=:latitude, longitude=:longitude, building_material_type=:building_material_type, building_condition=:building_condition, water_supply=:water_supply, electricity=:electricity, road_condition=:road_condition, estimated_travel_time=:estimated_travel_time, near_main_road=:near_main_road, is_safe_shelter=:is_safe_shelter, is_active=:is_active, updated_at=NOW() WHERE shelter_id=:id');
        $stmt->execute([
            ':id' => (int)$_POST['shelter_id'],
            ':barangay' => $_POST['barangay'],
            ':owner_name' => $_POST['owner_name'],
            ':capacity' => (int)$_POST['capacity'],
            ':typhoon_zone' => $_POST['typhoon_zone'],
            ':flood_zone' => $_POST['flood_zone'],
            ':landslide_zone' => $_POST['landslide_zone'],
            ':liquefaction_zone' => $_POST['liquefaction_zone'],
            ':storm_surge_zone' => $_POST['storm_surge_zone'],
            ':elevation' => (float)$_POST['elevation'],
            ':latitude' => (float)$_POST['latitude'],
            ':longitude' => (float)$_POST['longitude'],
            ':building_material_type' => $_POST['building_material_type'],
            ':building_condition' => $_POST['building_condition'],
            ':water_supply' => $_POST['water_supply'],
            ':electricity' => $_POST['electricity'],
            ':road_condition' => $_POST['road_condition'],
            ':estimated_travel_time' => (int)$_POST['estimated_travel_time'],
            ':near_main_road' => $_POST['near_main_road'],
            ':is_safe_shelter' => (int)$_POST['is_safe_shelter'],
            ':is_active' => (int)$_POST['is_active'],
        ]);
        $message = 'Shelter updated';
    }

    if ($action === 'delete') {
        $stmt = $pdo->prepare('DELETE FROM shelters WHERE shelter_id = :id');
        $stmt->execute([':id' => (int)$_POST['shelter_id']]);
        $message = 'Shelter deleted';
    }
}

// Fetch shelters
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $q = "%$search%";
    $stmt = $pdo->prepare('SELECT * FROM shelters WHERE barangay LIKE :q OR owner_name LIKE :q ORDER BY barangay, owner_name');
    $stmt->execute([':q' => $q]);
} else {
    $stmt = $pdo->query('SELECT * FROM shelters ORDER BY barangay, owner_name');
}
$shelters = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Shelters CRUD</title>
    <link href="../css/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="m-0">Shelters</h2>
        <div>
            <a class="btn btn-secondary" href="../login.php?logout=1">Logout</a>
        </div>
    </div>
    <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form class="row g-2 mb-3" method="get">
        <div class="col-sm-6 col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Search barangay/owner" value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="col-auto">
            <button class="btn btn-primary">Search</button>
        </div>
        <div class="col-auto">
            <a href="index.php" class="btn btn-secondary">Clear</a>
        </div>
    </form>

    <div class="card mb-4">
        <div class="card-header">Create Shelter</div>
        <div class="card-body">
            <form method="post" class="row g-3">
                <input type="hidden" name="action" value="create">
                <div class="col-md-3"><label class="form-label">Barangay</label><input name="barangay" class="form-control" required></div>
                <div class="col-md-3"><label class="form-label">Owner Name</label><input name="owner_name" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Capacity</label><input type="number" min="0" name="capacity" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Elevation</label><input type="number" step="0.01" name="elevation" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Latitude</label><input type="number" step="0.00000001" name="latitude" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Longitude</label><input type="number" step="0.00000001" name="longitude" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Bldg Material</label><input name="building_material_type" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Bldg Condition</label><input name="building_condition" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Water</label><input name="water_supply" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Electricity</label><input name="electricity" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Road</label><input name="road_condition" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Travel Time (min)</label><input type="number" min="0" name="estimated_travel_time" class="form-control" required></div>
                <div class="col-md-2"><label class="form-label">Near Main Road</label>
                    <select name="near_main_road" class="form-select" required>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">Safe Shelter</label>
                    <select name="is_safe_shelter" class="form-select">
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">Active</label>
                    <select name="is_active" class="form-select">
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">Typhoon Zone</label>
                    <select name="typhoon_zone" class="form-select" required>
                        <option>Yes</option><option>No</option>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">Flood Zone</label>
                    <select name="flood_zone" class="form-select" required>
                        <option>Yes</option><option>No</option>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">Landslide Zone</label>
                    <select name="landslide_zone" class="form-select" required>
                        <option>Yes</option><option>No</option>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">Liquefaction Zone</label>
                    <select name="liquefaction_zone" class="form-select" required>
                        <option>Yes</option><option>No</option>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label">Storm Surge</label>
                    <select name="storm_surge_zone" class="form-select" required>
                        <option>Yes</option><option>No</option>
                    </select>
                </div>
                <div class="col-12">
                    <button class="btn btn-success">Create</button>
                </div>
            </form>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-bordered align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Barangay</th>
                    <th>Owner</th>
                    <th>Capacity</th>
                    <th>Lat</th>
                    <th>Lng</th>
                    <th>Active</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($shelters as $s): ?>
                <tr>
                    <td><?= (int)$s['shelter_id'] ?></td>
                    <td><?= htmlspecialchars($s['barangay']) ?></td>
                    <td><?= htmlspecialchars($s['owner_name']) ?></td>
                    <td><?= (int)$s['capacity'] ?></td>
                    <td><?= htmlspecialchars($s['latitude']) ?></td>
                    <td><?= htmlspecialchars($s['longitude']) ?></td>
                    <td><?= (int)$s['is_active'] ? 'Yes' : 'No' ?></td>
                    <td>
                        <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#edit<?= (int)$s['shelter_id'] ?>">Edit</button>
                        <form method="post" class="d-inline" onsubmit="return confirm('Delete this shelter?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="shelter_id" value="<?= (int)$s['shelter_id'] ?>">
                            <button class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <tr class="collapse" id="edit<?= (int)$s['shelter_id'] ?>">
                    <td colspan="8">
                        <form method="post" class="row g-2">
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="shelter_id" value="<?= (int)$s['shelter_id'] ?>">
                            <div class="col-md-2"><label class="form-label">Barangay</label><input name="barangay" class="form-control" value="<?= htmlspecialchars($s['barangay']) ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Owner</label><input name="owner_name" class="form-control" value="<?= htmlspecialchars($s['owner_name']) ?>" required></div>
                            <div class="col-md-1"><label class="form-label">Capacity</label><input type="number" min="0" name="capacity" class="form-control" value="<?= (int)$s['capacity'] ?>" required></div>
                            <div class="col-md-1"><label class="form-label">Elev</label><input type="number" step="0.01" name="elevation" class="form-control" value="<?= htmlspecialchars($s['elevation']) ?>" required></div>
                            <div class="col-md-1"><label class="form-label">Lat</label><input type="number" step="0.00000001" name="latitude" class="form-control" value="<?= htmlspecialchars($s['latitude']) ?>" required></div>
                            <div class="col-md-1"><label class="form-label">Lng</label><input type="number" step="0.00000001" name="longitude" class="form-control" value="<?= htmlspecialchars($s['longitude']) ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Bldg Material</label><input name="building_material_type" class="form-control" value="<?= htmlspecialchars($s['building_material_type']) ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Bldg Condition</label><input name="building_condition" class="form-control" value="<?= htmlspecialchars($s['building_condition']) ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Water</label><input name="water_supply" class="form-control" value="<?= htmlspecialchars($s['water_supply']) ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Electricity</label><input name="electricity" class="form-control" value="<?= htmlspecialchars($s['electricity']) ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Road</label><input name="road_condition" class="form-control" value="<?= htmlspecialchars($s['road_condition']) ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Time (min)</label><input type="number" min="0" name="estimated_travel_time" class="form-control" value="<?= (int)$s['estimated_travel_time'] ?>" required></div>
                            <div class="col-md-2"><label class="form-label">Near Main Road</label>
                                <select name="near_main_road" class="form-select">
                                    <option<?= $s['near_main_road']==='Yes'?' selected':'' ?>>Yes</option>
                                    <option<?= $s['near_main_road']==='No'?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2"><label class="form-label">Safe</label>
                                <select name="is_safe_shelter" class="form-select">
                                    <option value="1"<?= (int)$s['is_safe_shelter']===1?' selected':'' ?>>Yes</option>
                                    <option value="0"<?= (int)$s['is_safe_shelter']===0?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2"><label class="form-label">Active</label>
                                <select name="is_active" class="form-select">
                                    <option value="1"<?= (int)$s['is_active']===1?' selected':'' ?>>Yes</option>
                                    <option value="0"<?= (int)$s['is_active']===0?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2"><label class="form-label">Typhoon</label>
                                <select name="typhoon_zone" class="form-select">
                                    <option<?= $s['typhoon_zone']==='Yes'?' selected':'' ?>>Yes</option>
                                    <option<?= $s['typhoon_zone']==='No'?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2"><label class="form-label">Flood</label>
                                <select name="flood_zone" class="form-select">
                                    <option<?= $s['flood_zone']==='Yes'?' selected':'' ?>>Yes</option>
                                    <option<?= $s['flood_zone']==='No'?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2"><label class="form-label">Landslide</label>
                                <select name="landslide_zone" class="form-select">
                                    <option<?= $s['landslide_zone']==='Yes'?' selected':'' ?>>Yes</option>
                                    <option<?= $s['landslide_zone']==='No'?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2"><label class="form-label">Liquefaction</label>
                                <select name="liquefaction_zone" class="form-select">
                                    <option<?= $s['liquefaction_zone']==='Yes'?' selected':'' ?>>Yes</option>
                                    <option<?= $s['liquefaction_zone']==='No'?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-md-2"><label class="form-label">Storm Surge</label>
                                <select name="storm_surge_zone" class="form-select">
                                    <option<?= $s['storm_surge_zone']==='Yes'?' selected':'' ?>>Yes</option>
                                    <option<?= $s['storm_surge_zone']==='No'?' selected':'' ?>>No</option>
                                </select>
                            </div>
                            <div class="col-12"><button class="btn btn-primary">Save Changes</button></div>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="../js/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


